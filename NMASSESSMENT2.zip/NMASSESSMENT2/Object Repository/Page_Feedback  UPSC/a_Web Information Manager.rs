<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Web Information Manager</name>
   <tag></tag>
   <elementGuidId>b6a08cc5-ca6f-4405-9e9a-22f213428a35</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-cmf-content-footer-region-block']/footer/div/div/ul/li[4]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Web Information Manager&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6d46a624-c34e-423f-81d0-832c85f795ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/web-information-manager</value>
      <webElementGuid>ddbbe917-710f-449b-8bc5-81e402d19494</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Web Information Manager</value>
      <webElementGuid>e587cdfb-76b3-401e-b5ff-aa318bea0876</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-cmf-content-footer-region-block&quot;)/footer[@class=&quot;wrapper footer-wrapper&quot;]/div[@class=&quot;footer-top-wrapper&quot;]/div[@class=&quot;container footer-top-container&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf&quot;]/a[1]</value>
      <webElementGuid>47da2aaf-a35b-423f-8f52-eda3fa0c8659</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-cmf-content-footer-region-block']/footer/div/div/ul/li[4]/a</value>
      <webElementGuid>a092f4f5-35c6-4170-baa3-d2318cbb65d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Web Information Manager')]</value>
      <webElementGuid>10c28bf1-270c-4597-8d6f-c6c35089d93d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact us'])[1]/following::a[1]</value>
      <webElementGuid>de883b92-447f-4309-b11d-c646cdd05f1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Help'])[1]/following::a[2]</value>
      <webElementGuid>5828a334-93b4-4d10-997b-e9b6d56a1fb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[3]/preceding::a[1]</value>
      <webElementGuid>53f5e190-1eba-401f-84f1-dd87cd5fae1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Privacy Policy'])[1]/preceding::a[2]</value>
      <webElementGuid>5c539879-ce62-417a-a1b0-525207945610</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Web Information Manager']/parent::*</value>
      <webElementGuid>140b61ec-41d9-465e-9265-3d3ad1743665</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/web-information-manager')]</value>
      <webElementGuid>53c3ecb1-5b29-468a-8db9-78f4785c6801</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//footer/div/div/ul/li[4]/a</value>
      <webElementGuid>04402dee-bc51-46c2-922f-0f0f6eb8326e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/web-information-manager' and (text() = 'Web Information Manager' or . = 'Web Information Manager')]</value>
      <webElementGuid>03adcfc1-795d-4b83-a51d-e38276e1718e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
