<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Recruitment cases kept on hold on account_51ce53</name>
   <tag></tag>
   <elementGuidId>9e6eeefa-2cdc-474f-b918-8c296e240626</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-2777 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[8]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Recruitment cases kept on hold on account of Pending Litigations&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>fe4097fb-2073-4111-9f47-43ab978abf54</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/content/recruitment-cases-kept-hold-account-pending-litigations</value>
      <webElementGuid>24abef51-8004-474d-b5a2-019c8007e8db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Recruitment cases kept on hold on account of Pending Litigations</value>
      <webElementGuid>d9813f3f-20c2-4a67-9ff5-c8acb1cc6c8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-2777&quot;]/a[1]</value>
      <webElementGuid>9e7b2f0e-43d7-4ea5-9472-00a21bcf8cf8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[8]/a</value>
      <webElementGuid>91ccda92-9eec-44ee-ab29-bb71428001b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Recruitment cases kept on hold on account of Pending Litigations')])[2]</value>
      <webElementGuid>f485204c-bce0-4e7e-909a-51417beec5ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Requisition'])[3]/following::a[1]</value>
      <webElementGuid>f48bec60-94f5-48c1-bedf-a11717f57a26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Tests'])[2]/following::a[2]</value>
      <webElementGuid>26288650-fee2-4b72-9dd6-04e041a90e78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Representation on Question Papers'])[3]/preceding::a[1]</value>
      <webElementGuid>5cb71d93-bf9a-4a5d-b578-52828953cb26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Requisition'])[4]/preceding::a[3]</value>
      <webElementGuid>6f05b772-9033-4ed7-8dee-35295f43c120</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/content/recruitment-cases-kept-hold-account-pending-litigations')])[2]</value>
      <webElementGuid>64f519ef-14dd-4f55-a750-9c2d1efe5289</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[8]/a</value>
      <webElementGuid>fedac398-3a8d-466e-9732-f4d868237375</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/content/recruitment-cases-kept-hold-account-pending-litigations' and (text() = 'Recruitment cases kept on hold on account of Pending Litigations' or . = 'Recruitment cases kept on hold on account of Pending Litigations')]</value>
      <webElementGuid>e9823ec7-937e-4923-9ce7-a852771e2a68</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
