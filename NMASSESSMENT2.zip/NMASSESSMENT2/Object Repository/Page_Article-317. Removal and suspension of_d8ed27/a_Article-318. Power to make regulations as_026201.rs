<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-318. Power to make regulations as_026201</name>
   <tag></tag>
   <elementGuidId>4feb8173-963a-4a0a-95cb-d97874b65f6a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1469 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[4]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-318. Power to make regulations as to conditions of service of members and staff of the Commission.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5fb341fb-087e-4217-9de8-8bbde777a9cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-318-power-make-regulations-conditions-service-members-and-staff-commission</value>
      <webElementGuid>bcaacfa4-d6f5-4193-9daa-579675e20dbf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-318. Power to make regulations as to conditions of service of members and staff of the Commission.</value>
      <webElementGuid>2bff9e39-fe44-490c-9898-e5473da35bbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1469&quot;]/a[1]</value>
      <webElementGuid>11736df3-d4ab-4104-b8df-00489a379de6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[4]/a</value>
      <webElementGuid>d56cc5bb-1935-4d3a-b4fe-9b019c0a770e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-318. Power to make regulations as to conditions of service of members and staff of the Commission.')]</value>
      <webElementGuid>a830a37f-f1e1-41db-9b8c-88b968a387b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-317. Removal and suspension of a member of a Public Service Commission.'])[2]/following::a[1]</value>
      <webElementGuid>dd24db15-7957-47a3-b157-67324b60d643</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-316. Appointment and term of office of members.'])[1]/following::a[2]</value>
      <webElementGuid>ead4c76f-e8d0-433c-91d8-183f6fe4a388</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-320. Functions of Public Service Commissions.'])[1]/preceding::a[2]</value>
      <webElementGuid>17c88998-fe63-4be2-b6af-9f9ecede7e7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.'])[1]/preceding::a[3]</value>
      <webElementGuid>87b22348-0f43-45ef-88f7-68d4e01f0d4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-318. Power to make regulations as to conditions of service of members and staff of the Commission.']/parent::*</value>
      <webElementGuid>e9faf6cd-05cb-4af3-99d0-e201e6986f12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-318-power-make-regulations-conditions-service-members-and-staff-commission')]</value>
      <webElementGuid>f2a7e400-a7ba-473d-bddd-7ba35c47ac58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[4]/a</value>
      <webElementGuid>16ccc2b2-0673-4fa7-8c4f-781ac7e1535b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-318-power-make-regulations-conditions-service-members-and-staff-commission' and (text() = 'Article-318. Power to make regulations as to conditions of service of members and staff of the Commission.' or . = 'Article-318. Power to make regulations as to conditions of service of members and staff of the Commission.')]</value>
      <webElementGuid>92582c6e-0655-48bb-9037-2c577d926d11</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
