<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_General Technical Issues</name>
   <tag></tag>
   <elementGuidId>c462494a-2d10-4e41-9cf0-393acac3c689</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='container']/table/tbody/tr/td[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;सामान्य तकनीकी समस्याएं General Technical Issues&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e528f49f-a6ca-4b4e-a415-8d5e280331de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>oraauth/candidate/ORA-Recruitment_Performa.pdf</value>
      <webElementGuid>66a2ed7a-07c6-4fe4-baa0-2690696a49dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>30ea75b1-cae8-41e0-b279-9282a10a1c45</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>सामान्य तकनीकी समस्याएं 
General Technical Issues</value>
      <webElementGuid>f0fc1c61-f52c-4dcc-b36b-749c0cddbfe6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container&quot;)/table[1]/tbody[1]/tr[1]/td[2]/a[1]</value>
      <webElementGuid>21fd654e-5239-4447-ba88-861bb7816f9e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container']/table/tbody/tr/td[2]/a</value>
      <webElementGuid>cc5da41f-9e2b-46e5-a109-d4f1634a5efa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='नवीन पंजीकरण/New Registration'])[1]/following::a[2]</value>
      <webElementGuid>805301e1-7774-46b9-b42d-2e04ce3cab30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='सामान्य तकनीकी समस्याएं']/parent::*</value>
      <webElementGuid>fc8a9b7c-9b00-4653-b00d-1af2553af800</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'oraauth/candidate/ORA-Recruitment_Performa.pdf')]</value>
      <webElementGuid>8e7df86d-4c15-4c8b-95de-3ab2bcd91849</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/a</value>
      <webElementGuid>4e65fe61-7f47-4493-b4e7-4257cd971f98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'oraauth/candidate/ORA-Recruitment_Performa.pdf' and (text() = 'सामान्य तकनीकी समस्याएं 
General Technical Issues' or . = 'सामान्य तकनीकी समस्याएं 
General Technical Issues')]</value>
      <webElementGuid>70179ed2-c654-489f-b036-bd6b6876ea8b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
