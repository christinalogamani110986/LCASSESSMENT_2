<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Instructions for filling Application</name>
   <tag></tag>
   <elementGuidId>a1c62c6b-a306-48f6-8eee-cd863865ead7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>td > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='container']/table/tbody/tr/td/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;आवेदन भरने के लिए निर्देश Instructions for filling Application&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>de678069-571c-4595-b378-0b4a1e3f6495</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>oraauth/candidate/Instructionscandidates.pdf</value>
      <webElementGuid>43681228-beef-42fe-b7f2-affc9a64c999</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>37d939c5-e42f-43dc-b20d-a65c7279b038</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>  आवेदन भरने के लिए निर्देश  
      Instructions for filling Application
			
			 </value>
      <webElementGuid>c2d7b42b-4420-4dce-ba76-9a8f8aca5c1c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;container&quot;)/table[1]/tbody[1]/tr[1]/td[1]/a[1]</value>
      <webElementGuid>01337985-71c7-4998-ba19-6a8fe78d1a06</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='container']/table/tbody/tr/td/a</value>
      <webElementGuid>9c3ff7c1-2672-4d8e-991d-79d3975c4c84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='नवीन पंजीकरण/New Registration'])[1]/following::a[1]</value>
      <webElementGuid>30078df3-320f-4d3f-b325-dc7c03c561f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='पहले से पंजीकृत/Already Registered'])[1]/following::a[2]</value>
      <webElementGuid>0dcf2702-8814-4cd1-8e93-7314af39e4d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='आवेदन भरने के लिए निर्देश']/parent::*</value>
      <webElementGuid>bc5e16f1-eff9-433d-8e60-762ef1303fe1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'oraauth/candidate/Instructionscandidates.pdf')]</value>
      <webElementGuid>ce776bdf-cada-482d-8e46-7770b3fccf78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/a</value>
      <webElementGuid>443c5cf8-8d50-422e-b162-9ba41f2b533a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'oraauth/candidate/Instructionscandidates.pdf' and (text() = '  आवेदन भरने के लिए निर्देश  
      Instructions for filling Application
			
			 ' or . = '  आवेदन भरने के लिए निर्देश  
      Instructions for filling Application
			
			 ')]</value>
      <webElementGuid>febf277f-0ad3-48d8-b5d0-d09a78c5eca6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
