<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Forms  Downloads</name>
   <tag></tag>
   <elementGuidId>fe180a97-0c73-454b-bec8-582a08fec9f1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Forms &amp; Downloads&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9cb90d64-7c4e-4c36-86f5-eb921bd98e3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/forms-downloads</value>
      <webElementGuid>82978c83-bbb1-4238-a018-f4ac5a827b3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Forms &amp; Downloads</value>
      <webElementGuid>126af258-c0d5-4f7b-925d-d3e767c9f734</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf&quot;]/a[1]</value>
      <webElementGuid>3ba63f84-a50c-49e6-aa46-5ad2f34c1f06</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[6]/a</value>
      <webElementGuid>5a4c8090-f863-4813-8bba-b2f575e95306</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Forms &amp; Downloads')]</value>
      <webElementGuid>57dd8fba-a9bd-4b8f-bcf2-7f3bb4bc2da1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Others'])[1]/following::a[1]</value>
      <webElementGuid>d2bf3ad1-8d83-4bc4-9d06-c0dfcb382173</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State Government'])[1]/following::a[2]</value>
      <webElementGuid>a0c6d2f0-33e3-4d07-931a-6fab12c5fff6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FAQs'])[1]/preceding::a[1]</value>
      <webElementGuid>b06ad9f6-6de4-42bc-84cd-8547abafa149</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RTI'])[1]/preceding::a[2]</value>
      <webElementGuid>60a94f21-0622-4234-8ce6-64ce7a1ffd72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Forms &amp; Downloads']/parent::*</value>
      <webElementGuid>0ab6aa30-841c-4bc1-9761-c5c28f9631bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/forms-downloads')]</value>
      <webElementGuid>a5be38d6-54f4-4be6-8999-83cf904edc84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/ul/li[6]/a</value>
      <webElementGuid>cc5fd8f1-452c-4956-9d86-b2917bfd67a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/forms-downloads' and (text() = 'Forms &amp; Downloads' or . = 'Forms &amp; Downloads')]</value>
      <webElementGuid>cf09d733-e023-4934-9ac7-528e460c5075</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
