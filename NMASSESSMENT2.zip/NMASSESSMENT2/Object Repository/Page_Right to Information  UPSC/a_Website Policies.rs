<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Website Policies</name>
   <tag></tag>
   <elementGuidId>c9b38a4f-6c4c-40e8-abbe-f873be18f753</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.container.footer-top-container > ul.menu.nav > li.first.leaf > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-cmf-content-footer-region-block']/footer/div/div/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Website Policies&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>63b88b15-6870-4f39-8fe2-32b992efd5f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/website-policy</value>
      <webElementGuid>329f7394-3a2a-4b7b-a930-ecfd7c4e26cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Website Policies</value>
      <webElementGuid>1c47fdf0-6267-4530-b222-54228d2e7b57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-cmf-content-footer-region-block&quot;)/footer[@class=&quot;wrapper footer-wrapper&quot;]/div[@class=&quot;footer-top-wrapper&quot;]/div[@class=&quot;container footer-top-container&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;first leaf&quot;]/a[1]</value>
      <webElementGuid>8e3d26e1-65e2-4bb5-bd9f-73d006391e73</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-cmf-content-footer-region-block']/footer/div/div/ul/li/a</value>
      <webElementGuid>bfdc5cef-88c8-4e06-84e8-2f4a3e2694c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Website Policies')]</value>
      <webElementGuid>3c45e8dc-3571-443e-b0fc-99eba24fa01d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>> View Archives'])[1]/following::a[1]</value>
      <webElementGuid>4701fbb4-6464-4fbc-a061-2b69cb0808f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(45.28 MB)'])[1]/following::a[2]</value>
      <webElementGuid>efce85d2-e616-4dba-86ed-4505f227df0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Help'])[1]/preceding::a[1]</value>
      <webElementGuid>ce58e2cd-db54-4755-ba5d-ebfe633c7e70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact us'])[1]/preceding::a[2]</value>
      <webElementGuid>5455af20-fc1b-4bea-a96d-c7f2c18153fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Website Policies']/parent::*</value>
      <webElementGuid>891300cb-6ff5-42bf-9caa-136d0356eb58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/website-policy')]</value>
      <webElementGuid>48486c67-3af3-4ad0-a3c3-7e8fa868198c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//footer/div/div/ul/li/a</value>
      <webElementGuid>17432155-af14-458a-bc3b-f12507168721</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/website-policy' and (text() = 'Website Policies' or . = 'Website Policies')]</value>
      <webElementGuid>8afc2090-1074-43ed-b238-b776a79a93d5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
