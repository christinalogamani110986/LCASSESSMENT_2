<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Recruitment Rules</name>
   <tag></tag>
   <elementGuidId>3149d62a-864e-49b8-81f9-de695e6f7957</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.has-children.menu-mlid-1672 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[4]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Recruitment Rules&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>06ec0d4a-4df2-482e-b3b8-cda1efa3a2d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/divisions/administration/recruitment-rules</value>
      <webElementGuid>bff55216-02ba-4c14-9485-0e7c4ec89569</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Recruitment Rules</value>
      <webElementGuid>a182963b-079a-4abe-88e3-b300a5227625</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf has-children menu-mlid-1672&quot;]/a[1]</value>
      <webElementGuid>591fe96a-7a5a-4a51-a4bf-0b9eb627ee1a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[4]/a</value>
      <webElementGuid>7275509e-d90b-4221-929a-576065cb1fdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Recruitment Rules')]</value>
      <webElementGuid>4e92ebf4-b575-46fe-851c-4dc0dfd167fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Functions'])[3]/following::a[1]</value>
      <webElementGuid>d72cd360-1be9-4090-bd1e-6a28b1a09a1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Personnel'])[1]/following::a[2]</value>
      <webElementGuid>3b0f1269-7b6c-4865-9b85-49ed43f8f54d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Work with Us'])[1]/preceding::a[1]</value>
      <webElementGuid>7066eab9-5ece-479b-9f52-ce1543f95e69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Functions'])[4]/preceding::a[3]</value>
      <webElementGuid>f6e15c15-a046-47e7-85fe-6dff5b7f1dcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Recruitment Rules']/parent::*</value>
      <webElementGuid>b5a27f5e-2f59-47f2-ae40-16f160ac354a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/divisions/administration/recruitment-rules')]</value>
      <webElementGuid>8db42823-68ea-42d9-ba6a-91410d4f0b21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[4]/a</value>
      <webElementGuid>5fb9093e-bb7d-474a-8ae3-9607d39e5335</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/divisions/administration/recruitment-rules' and (text() = 'Recruitment Rules' or . = 'Recruitment Rules')]</value>
      <webElementGuid>4e5cc548-027a-4838-9383-92193be78675</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
