<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-315. Public Service Commissions f_9342bd</name>
   <tag></tag>
   <elementGuidId>56585e4b-a024-45c5-9313-0e0ecd761aff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.first.leaf.menu-mlid-1466 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-3']/div/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-315. Public Service Commissions for the Union and for the States.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>811feebd-0f87-4b8c-a5ef-2f5f5b946298</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-315-public-service-commissions-union-and-states</value>
      <webElementGuid>b6cbb8f3-914b-4311-adfe-169b8f29e22b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-315. Public Service Commissions for the Union and for the States.</value>
      <webElementGuid>eead382e-1fa7-40eb-9c38-7c6d824b3270</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-3&quot;)/div[@class=&quot;menu-block-wrapper menu-block-3 menu-name-main-menu parent-mlid-0 menu-level-3&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;first leaf menu-mlid-1466&quot;]/a[1]</value>
      <webElementGuid>410833e4-5f86-45bf-a731-d9fcc182b288</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-3']/div/ul/li/a</value>
      <webElementGuid>2449a2f1-9c4c-41ca-9a0d-0881d45f00e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-315. Public Service Commissions for the Union and for the States.')]</value>
      <webElementGuid>372313a8-3368-4b39-bc27-df44b99dea7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Constitutional Provisions'])[4]/following::a[1]</value>
      <webElementGuid>d2d1ff79-45d7-4758-858e-4a69a5cf9ba4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Virtual Tour of Museum'])[2]/following::a[2]</value>
      <webElementGuid>ca1391b1-0d81-410f-bf31-cb4ff465b69a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-316. Appointment and term of office of members.'])[1]/preceding::a[1]</value>
      <webElementGuid>1f7e93d3-d6dd-4513-9d1d-9cd4405a0d30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-317. Removal and suspension of a member of a Public Service Commission.'])[1]/preceding::a[2]</value>
      <webElementGuid>75f531eb-6c37-49a0-b416-8037a436cc66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-315. Public Service Commissions for the Union and for the States.']/parent::*</value>
      <webElementGuid>9d6df805-490d-4358-b12e-aa0261405905</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-315-public-service-commissions-union-and-states')]</value>
      <webElementGuid>9b7f5cba-2fbd-4ba2-aba8-85898015ae03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/ul/li/a</value>
      <webElementGuid>24325203-8826-456a-ae63-dc76d752cda1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-315-public-service-commissions-union-and-states' and (text() = 'Article-315. Public Service Commissions for the Union and for the States.' or . = 'Article-315. Public Service Commissions for the Union and for the States.')]</value>
      <webElementGuid>12c4b674-4e39-47cd-b028-36fe225c2e0c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
