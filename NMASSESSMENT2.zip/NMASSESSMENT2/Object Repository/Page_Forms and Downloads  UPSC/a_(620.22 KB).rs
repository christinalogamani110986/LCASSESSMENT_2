<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_(620.22 KB)</name>
   <tag></tag>
   <elementGuidId>51386626-00ad-40a4-8e7e-07eae886c248</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.views-row.views-row-2.views-row-even > div.views-field.views-field-php > span.field-content > ul.arrows > li > a[title=&quot;PDF file that opens in a new window.&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'(620.22 KB)')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;(620.22 KB)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f07560f3-80c5-442e-bcb1-769cf140b7a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://upsc.gov.in/sites/default/files/TA-Form-Candidates-Engl_Revised-010323.pdf</value>
      <webElementGuid>a1e7807e-013b-4b0f-bdfd-380dc90fe6a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_BLANK</value>
      <webElementGuid>b29118be-ff83-4093-82ea-92f5fb5fdfa7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>PDF file that opens in a new window.</value>
      <webElementGuid>63beb885-215d-4211-b66a-99ec13abc219</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> (620.22 KB) </value>
      <webElementGuid>57a6ad99-3f56-40e8-8031-87ff6093f359</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html not-front not-logged-in no-sidebars page-forms-downloads i18n-en&quot;]/section[@class=&quot;wrapper body-wrapper&quot;]/div[@class=&quot;container body-container inner-body fontSize&quot;]/div[@class=&quot;col-xs-12 col-sm-9 col-md-9 content-container fontSize&quot;]/div[@class=&quot;inner-right&quot;]/div[@class=&quot;view view-recruitment-performas view-id-recruitment_performas view-display-id-page_1 view-dom-id-f09ff50b5d02dc16e2e1c9167ae26fe7&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;views-row views-row-2 views-row-even&quot;]/div[@class=&quot;views-field views-field-php&quot;]/span[@class=&quot;field-content&quot;]/ul[@class=&quot;arrows&quot;]/li[1]/a[1]</value>
      <webElementGuid>075cd878-d9ce-49d0-800f-567b21344f0b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'(620.22 KB)')]</value>
      <webElementGuid>42d95f8f-1b7d-4285-94a0-ef8b2a0e42a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(419.44 KB)'])[1]/following::a[1]</value>
      <webElementGuid>805bae49-b68f-45ed-aef2-f9be64fa2ab8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(696.59 KB)'])[1]/preceding::a[1]</value>
      <webElementGuid>b4d8bbbe-59ff-4d9f-99ca-bc5a65fdbf24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='(620.22 KB)']/parent::*</value>
      <webElementGuid>970f28c3-ef7b-4581-bfe3-2cc1893301ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://upsc.gov.in/sites/default/files/TA-Form-Candidates-Engl_Revised-010323.pdf')]</value>
      <webElementGuid>b8f029e2-050d-4f06-b836-51ba0d608433</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/span/ul/li/a</value>
      <webElementGuid>96ef15a2-5c6f-4c69-8096-433563482685</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://upsc.gov.in/sites/default/files/TA-Form-Candidates-Engl_Revised-010323.pdf' and @title = 'PDF file that opens in a new window.' and (text() = ' (620.22 KB) ' or . = ' (620.22 KB) ')]</value>
      <webElementGuid>228756d4-f64b-4ac5-b143-275ba2441604</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
