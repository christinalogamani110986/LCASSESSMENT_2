<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Web Information Manager</name>
   <tag></tag>
   <elementGuidId>0b07fe59-ad74-4ef8-8cc4-c524d9dc19d6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-cmf-content-footer-region-block']/footer/div/div/ul/li[4]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Web Information Manager&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2c8ca341-47d2-4886-be39-2f691b32481b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/web-information-manager</value>
      <webElementGuid>fe125f0e-939e-4a32-9327-206491bb8bbc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Web Information Manager</value>
      <webElementGuid>a9439a47-6729-405f-9597-2014059a7a31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-cmf-content-footer-region-block&quot;)/footer[@class=&quot;wrapper footer-wrapper&quot;]/div[@class=&quot;footer-top-wrapper&quot;]/div[@class=&quot;container footer-top-container&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf&quot;]/a[1]</value>
      <webElementGuid>3024d875-82c3-47c8-8a90-4287991d6559</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-cmf-content-footer-region-block']/footer/div/div/ul/li[4]/a</value>
      <webElementGuid>4331dcae-f666-48f8-ab25-b864796206ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Web Information Manager')]</value>
      <webElementGuid>fadf7f52-a899-4ac7-9f16-277cb5801a41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact us'])[1]/following::a[1]</value>
      <webElementGuid>f73f6195-21d4-4f81-9800-34690cc1f8ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Help'])[3]/following::a[2]</value>
      <webElementGuid>fb8d72cc-4497-456a-9d7e-ab6e729d3870</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[1]/preceding::a[1]</value>
      <webElementGuid>6b5ac0d1-468b-4541-9cd0-42340c465a37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Privacy Policy'])[1]/preceding::a[2]</value>
      <webElementGuid>23d51eb0-ce94-43ae-b452-48125c2ca109</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Web Information Manager']/parent::*</value>
      <webElementGuid>59be7d31-c207-4ec2-80c4-e61efe2dcf93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/web-information-manager')]</value>
      <webElementGuid>3594e412-cf3f-458c-8e9c-f472777b507c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//footer/div/div/ul/li[4]/a</value>
      <webElementGuid>26f5da15-83c5-4fbc-9e2a-cbcc0ac9b6a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/web-information-manager' and (text() = 'Web Information Manager' or . = 'Web Information Manager')]</value>
      <webElementGuid>b5f974f2-af7f-4575-bc0f-fe9ee4b9cd90</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
