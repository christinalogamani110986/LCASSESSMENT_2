<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-317. Removal and suspension of a _1a82c7</name>
   <tag></tag>
   <elementGuidId>2925139c-a780-4fb3-824d-79ea75792ce1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1468 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[3]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-317. Removal and suspension of a member of a Public Service Commission.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>129ac52a-a58b-4461-ad85-1c1e4428335d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-317-removal-and-suspension-member-public-service-commission</value>
      <webElementGuid>ebcc7a4e-555f-4616-8341-21cb02d2ab9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-317. Removal and suspension of a member of a Public Service Commission.</value>
      <webElementGuid>f82b1bbd-cded-48c4-ac2c-492ea349763f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1468&quot;]/a[1]</value>
      <webElementGuid>1e460596-6040-43f4-8375-b63994594486</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[3]/a</value>
      <webElementGuid>53f71d41-ab01-4f9d-95ea-40baa9f9b040</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-317. Removal and suspension of a member of a Public Service Commission.')]</value>
      <webElementGuid>ed47c4f6-a20b-440e-9bc9-963dfbb5be53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-316. Appointment and term of office of members.'])[2]/following::a[1]</value>
      <webElementGuid>42f255e6-6c50-4181-9eef-99c349f7ea88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-315. Public Service Commissions for the Union and for the States.'])[1]/following::a[2]</value>
      <webElementGuid>51763171-0631-4b05-855b-bfac92d5ad70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-320. Functions of Public Service Commissions.'])[1]/preceding::a[3]</value>
      <webElementGuid>3ff0f278-0934-4e6e-887f-2aee6942740c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.'])[1]/preceding::a[4]</value>
      <webElementGuid>756f2963-5b22-4287-8a3d-26e75c6fdb50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-317. Removal and suspension of a member of a Public Service Commission.']/parent::*</value>
      <webElementGuid>9540d96a-18bd-49a1-b303-331c1e4a1ec3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-317-removal-and-suspension-member-public-service-commission')]</value>
      <webElementGuid>a491b2ba-dbe8-420a-90ab-954c1021ec94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[3]/a</value>
      <webElementGuid>14ef0bad-fbfd-4475-91ca-e8c39c181f06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-317-removal-and-suspension-member-public-service-commission' and (text() = 'Article-317. Removal and suspension of a member of a Public Service Commission.' or . = 'Article-317. Removal and suspension of a member of a Public Service Commission.')]</value>
      <webElementGuid>40f129fa-ec70-4cd3-952d-f6e9cfbaa57a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
