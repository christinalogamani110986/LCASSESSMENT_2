<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Central Government</name>
   <tag></tag>
   <elementGuidId>40295356-1383-4114-aaab-db26a7e030a3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[5]/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Central Government&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a9c02298-6605-46b4-b723-b164bef975a1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/government-user/central-government</value>
      <webElementGuid>99988e46-cd94-46ed-b9b4-64dc88821511</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Central Government</value>
      <webElementGuid>9be70eae-3964-41fe-a095-49f513057a3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;expanded dropdown&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[@class=&quot;first leaf fontSize&quot;]/a[1]</value>
      <webElementGuid>7af17ca6-630e-4d32-ba5f-a1fdf97e427b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[5]/ul/li/a</value>
      <webElementGuid>fc45d638-b92a-42b8-b2ca-7d842cda122f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Central Government')]</value>
      <webElementGuid>97f35ed2-2fb2-4be6-9fc5-0c78df8f142f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Government Users'])[1]/following::a[1]</value>
      <webElementGuid>e7d76e7d-6a41-42b1-8d9c-c643acbc4580</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Representation on Question Papers'])[2]/following::a[2]</value>
      <webElementGuid>d52c344e-9e57-4bee-8f60-94cf3b2783d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Union Territories Government'])[1]/preceding::a[1]</value>
      <webElementGuid>0e9b98fb-7a34-4bc8-adaf-a9a7334b29a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State Government'])[1]/preceding::a[2]</value>
      <webElementGuid>11c10fe8-cc14-4033-bd54-8432be999a5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Central Government']/parent::*</value>
      <webElementGuid>714bb5f0-47a6-4304-bb7a-b43986aaa84c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/government-user/central-government')]</value>
      <webElementGuid>c4273013-e32b-4a95-ac0d-668ef126d81e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/ul/li/a</value>
      <webElementGuid>109e6656-0a82-4de7-b843-06f5697d9a4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/government-user/central-government' and (text() = 'Central Government' or . = 'Central Government')]</value>
      <webElementGuid>4350382b-1fc5-44c3-aaa0-5182886b83ac</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
