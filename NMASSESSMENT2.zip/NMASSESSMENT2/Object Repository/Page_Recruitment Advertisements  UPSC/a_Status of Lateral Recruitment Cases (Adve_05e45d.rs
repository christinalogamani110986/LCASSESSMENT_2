<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Status of Lateral Recruitment Cases (Adve_05e45d</name>
   <tag></tag>
   <elementGuidId>75236ba5-a06f-43cc-a068-abe18fe47651</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.has-children.menu-mlid-3224 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Status of Lateral Recruitment Cases (Advertisement-wise)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>dacfb849-16fd-49b0-aaab-b6ecdba7c9f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/recruitment/lateral-recruitments</value>
      <webElementGuid>82cd482f-2cd8-4df4-bdc3-8ecfadefb0ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Status of Lateral Recruitment Cases (Advertisement-wise)</value>
      <webElementGuid>4c0ecaad-f026-45f8-83c1-9c8b29e311a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf has-children menu-mlid-3224&quot;]/a[1]</value>
      <webElementGuid>b5660d78-e6a8-4a4b-a119-9d195b2523a6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[2]/a</value>
      <webElementGuid>0a454ddc-03ed-41a6-9a7f-42fd380387a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Status of Lateral Recruitment Cases (Advertisement-wise)')])[2]</value>
      <webElementGuid>cf4d02b3-ade5-44bf-a0ca-c95ecedaf04b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Advertisements'])[2]/following::a[1]</value>
      <webElementGuid>a976333a-7cd5-48d2-a58d-6ecb1bf03f16</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Advertisements'])[1]/following::a[2]</value>
      <webElementGuid>e98a9e6e-4c9f-43ae-b336-27a57647673e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Recruitment Application (ORA)'])[2]/preceding::a[1]</value>
      <webElementGuid>6dbdcd17-50b1-411e-b0dc-3102e65afea8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status of Recruitment Cases (Advertisement-wise)'])[2]/preceding::a[2]</value>
      <webElementGuid>c72f41d7-9ed9-442a-b2ed-78562fb5f4d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/recruitment/lateral-recruitments')])[2]</value>
      <webElementGuid>40520321-081f-4a88-964d-05880f31f220</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[2]/a</value>
      <webElementGuid>be1899e0-e030-4291-94f3-8c79bd30999a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/recruitment/lateral-recruitments' and (text() = 'Status of Lateral Recruitment Cases (Advertisement-wise)' or . = 'Status of Lateral Recruitment Cases (Advertisement-wise)')]</value>
      <webElementGuid>3fd1e8c8-08b8-4c71-b7a1-f193d6bdd98d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
