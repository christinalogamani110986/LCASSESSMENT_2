<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-316. Appointment and term of offi_2c16a6</name>
   <tag></tag>
   <elementGuidId>ad8ccc88-ea14-4e97-bbc5-b44e66926674</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1467 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-316. Appointment and term of office of members.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5187a32b-8b6c-4423-a812-1da77685f143</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-316-appointment-and-term-office-members</value>
      <webElementGuid>9a8c8a3d-e031-47af-8d7b-1fb0b192352d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-316. Appointment and term of office of members.</value>
      <webElementGuid>5ec08c31-56b9-4691-85dc-a83f92b677ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1467&quot;]/a[1]</value>
      <webElementGuid>5319c350-3362-4e2c-bd2e-f27d56d1a1e2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[2]/a</value>
      <webElementGuid>db6c151d-0f8c-4c00-8e43-1647b4b030bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-316. Appointment and term of office of members.')]</value>
      <webElementGuid>7b07189a-13f4-4db0-92aa-4e42e1756d14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-315. Public Service Commissions for the Union and for the States.'])[2]/following::a[1]</value>
      <webElementGuid>c71b1638-a868-4f6b-87ab-8efc269e8cea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-315. Public Service Commissions for the Union and for the States.'])[1]/following::a[2]</value>
      <webElementGuid>c32a2f56-1e2a-4d96-83ec-01b7088d7748</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-317. Removal and suspension of a member of a Public Service Commission.'])[1]/preceding::a[1]</value>
      <webElementGuid>eb2ada84-d309-4226-af99-1b50c98e305a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-320. Functions of Public Service Commissions.'])[1]/preceding::a[4]</value>
      <webElementGuid>5de73833-6dd9-4b57-bb17-8b27f6d90237</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-316. Appointment and term of office of members.']/parent::*</value>
      <webElementGuid>d30281c8-3175-42d8-81ec-d6e74cc03fc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-316-appointment-and-term-office-members')]</value>
      <webElementGuid>a2c0956b-ee5d-42fc-847b-c4a0f1eb27aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[2]/a</value>
      <webElementGuid>05dbb38d-4e80-455c-98d9-dab40fe2fe46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-316-appointment-and-term-office-members' and (text() = 'Article-316. Appointment and term of office of members.' or . = 'Article-316. Appointment and term of office of members.')]</value>
      <webElementGuid>ad01b6ea-91d7-4019-89cb-4946d8883cc9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
