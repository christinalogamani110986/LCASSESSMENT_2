<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Interview Details 42 Posts of Labour Enfo_2dc322</name>
   <tag></tag>
   <elementGuidId>eef8e1db-6768-4d77-8cf5-acb16242e266</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.views-row.views-row-18.views-row-even > div.views-field.views-field-field-name-of-post-vaccancy > div.field-content > ul.arrows > li > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//marquee[@id='mymarquee']/div/div[2]/div[18]/div[2]/div/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>efd4ee16-c4fc-4f44-80f4-0e1e504565fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>whats-new/42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment/Interview Details</value>
      <webElementGuid>bedd7ab0-8a4e-4104-bb76-d94be4b31750</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment</value>
      <webElementGuid>8cf7a743-e833-42c1-970c-fb29807a4391</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html front not-logged-in two-sidebars page-node i18n-en&quot;]/header[1]/section[@class=&quot;slider-section&quot;]/div[@class=&quot;whats-new fontSize&quot;]/div[@class=&quot;whats-new-marq&quot;]/marquee[@id=&quot;mymarquee&quot;]/div[@class=&quot;view view-what-new view-id-what_new view-display-id-block view-what-new view-dom-id-ea1ed6dea60532fd72a6c69b0b8f1f51&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;views-row views-row-18 views-row-even&quot;]/div[@class=&quot;views-field views-field-field-name-of-post-vaccancy&quot;]/div[@class=&quot;field-content&quot;]/ul[@class=&quot;arrows&quot;]/li[1]/a[1]</value>
      <webElementGuid>06962b60-bb03-412f-9ba4-3f7cc7e158a6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//marquee[@id='mymarquee']/div/div[2]/div[18]/div[2]/div/ul/li/a</value>
      <webElementGuid>fa00702b-04e7-44de-a3ad-a058b0fc78ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment')]</value>
      <webElementGuid>8e190f6d-260a-4aee-8569-7e700522a30c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Interview Details: 07 posts of Assistant Public Prosecutor in CBI'])[1]/following::a[2]</value>
      <webElementGuid>247e2363-ae05-4493-803a-6e3950540db2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Final Result: 05 Posts of General Duty Medical Officer (Homoeopathy), GNCTD'])[1]/following::a[4]</value>
      <webElementGuid>3a548f99-a294-42ce-bf69-ffc5acf30ee7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Written Result (with name): National Defence Academy and Naval Academy Examination (I), 2024'])[1]/preceding::a[1]</value>
      <webElementGuid>47fb3555-a7cd-41b2-9eef-c7574c6ba838</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examination Time Table: Indian Economic Service - Indian Statistical Service Examination, 2024'])[1]/preceding::a[2]</value>
      <webElementGuid>7829c66c-bda7-429a-8700-b7879a7771fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment']/parent::*</value>
      <webElementGuid>dc1a33eb-4ea9-4fa9-9d08-ad06288e9922</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'whats-new/42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment/Interview Details')]</value>
      <webElementGuid>2f40d092-f493-4bd6-b0ad-56d8c4e80e82</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[18]/div[2]/div/ul/li/a</value>
      <webElementGuid>43dc2034-3bc8-4acf-8056-004ec235ec20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'whats-new/42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment/Interview Details' and (text() = 'Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment' or . = 'Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment')]</value>
      <webElementGuid>4845d471-5917-4935-8968-65ea92e2d26d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
