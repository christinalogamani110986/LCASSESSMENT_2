<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Constitutional Provisions</name>
   <tag></tag>
   <elementGuidId>2ebbe4d3-52a0-40b1-9537-36e9efa5fbc5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.collapsed.fontSize > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[2]/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#main-menu >> internal:role=link[name=&quot;Constitutional Provisions&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cbbf7fa1-7f9f-4467-9435-4a2e9b5b675b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions</value>
      <webElementGuid>9862bb22-93ed-4b52-bddb-a5fcb1fa8526</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Constitutional Provisions</value>
      <webElementGuid>794e633e-95f8-4180-9deb-1f7db0fc4411</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;expanded dropdown active&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[@class=&quot;collapsed fontSize&quot;]/a[1]</value>
      <webElementGuid>5e710a95-047a-4894-897c-828c7ce1033f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[2]/ul/li[2]/a</value>
      <webElementGuid>57d26356-3b63-4f66-9f11-11011e58e568</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Constitutional Provisions')]</value>
      <webElementGuid>3e0fabb7-5876-4cff-b7f7-6e5bfa87a974</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Historical Perspective'])[1]/following::a[1]</value>
      <webElementGuid>0c5dcf92-f2ab-4eb0-b9f3-40202a545abb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/following::a[2]</value>
      <webElementGuid>61c76bdb-44be-4108-a060-6296da1ba0b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Commission'])[1]/preceding::a[1]</value>
      <webElementGuid>893d25bf-b733-4412-8322-c6cd26ffb5b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Functions'])[1]/preceding::a[2]</value>
      <webElementGuid>1451f03e-b257-4131-9584-be469297102c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Constitutional Provisions']/parent::*</value>
      <webElementGuid>10ae61e1-7f33-4960-b57b-c740d33951ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions')]</value>
      <webElementGuid>82ba27be-6e79-4b00-a4df-4e8f1da76a22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[2]/a</value>
      <webElementGuid>39b2e207-3ea0-4d72-b3f0-301bc14dec70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions' and (text() = 'Constitutional Provisions' or . = 'Constitutional Provisions')]</value>
      <webElementGuid>91cff6f9-70b9-44a0-bf31-2017e81b168d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
