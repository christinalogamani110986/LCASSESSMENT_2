<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Representation on Question Papers</name>
   <tag></tag>
   <elementGuidId>dd5a7c56-f15a-41b9-a2dc-030bc8e7ddf8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.last.leaf.menu-mlid-2755 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-6']/div/ul/li[9]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Representation on Question Papers&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0f12e21c-612d-4edb-a8e8-5993f10f0be8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/recruitment/time-frame-representation</value>
      <webElementGuid>5490f688-d900-421a-9517-77b6e088f2bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Representation on Question Papers</value>
      <webElementGuid>a5c5f600-25c4-4314-8813-d1ec90c6ca90</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-6&quot;)/div[@class=&quot;menu-block-wrapper menu-block-6 menu-name-main-menu parent-mlid-617 menu-level-1&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;last leaf menu-mlid-2755&quot;]/a[1]</value>
      <webElementGuid>84101a41-d38c-4519-8eb6-2aa7447c1a8d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-6']/div/ul/li[9]/a</value>
      <webElementGuid>0c8c1399-5b8f-4eee-bb93-fb2e648dff9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Representation on Question Papers')])[3]</value>
      <webElementGuid>c4d05ad2-e8d3-4bdc-af3a-fa8e96c5cfbc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment cases kept on hold on account of Pending Litigations'])[2]/following::a[1]</value>
      <webElementGuid>00d86b93-9253-4888-a7ee-1f2ea82bd64f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Requisition'])[2]/following::a[2]</value>
      <webElementGuid>e03a2e6b-ec3b-4c83-8a03-2aec8117ab00</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examination Notifications'])[1]/preceding::a[1]</value>
      <webElementGuid>980b122f-af3c-42df-adae-71ca28d2d16a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Advertisements'])[1]/preceding::a[2]</value>
      <webElementGuid>89f7a887-c472-4e1b-83f2-37294b27f4fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/recruitment/time-frame-representation')])[2]</value>
      <webElementGuid>6ae46008-89a8-4497-9d59-3ba5c3803f9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/section/div/ul/li[9]/a</value>
      <webElementGuid>8eda8e93-abc3-4138-b1c4-6fe04623deaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/recruitment/time-frame-representation' and (text() = 'Representation on Question Papers' or . = 'Representation on Question Papers')]</value>
      <webElementGuid>083bc740-8e73-4b74-ac22-2699512a728b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
