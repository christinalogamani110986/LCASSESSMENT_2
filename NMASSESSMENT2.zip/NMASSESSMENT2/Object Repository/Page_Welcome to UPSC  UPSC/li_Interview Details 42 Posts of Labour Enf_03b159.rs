<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Interview Details 42 Posts of Labour Enf_03b159</name>
   <tag></tag>
   <elementGuidId>5f5c77bf-d67d-4460-8567-133694610dff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.views-row.views-row-18.views-row-even > div.views-field.views-field-field-name-of-post-vaccancy > div.field-content > ul.arrows > li</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//marquee[@id='mymarquee']/div/div[2]/div[18]/div[2]/div/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=&quot;Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>6736b199-d3c9-4087-8902-622b1e626376</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment</value>
      <webElementGuid>b8f73167-6767-4754-930c-062d39e729c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html front not-logged-in two-sidebars page-node i18n-en&quot;]/header[1]/section[@class=&quot;slider-section&quot;]/div[@class=&quot;whats-new fontSize&quot;]/div[@class=&quot;whats-new-marq&quot;]/marquee[@id=&quot;mymarquee&quot;]/div[@class=&quot;view view-what-new view-id-what_new view-display-id-block view-what-new view-dom-id-ea1ed6dea60532fd72a6c69b0b8f1f51&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;views-row views-row-18 views-row-even&quot;]/div[@class=&quot;views-field views-field-field-name-of-post-vaccancy&quot;]/div[@class=&quot;field-content&quot;]/ul[@class=&quot;arrows&quot;]/li[1]</value>
      <webElementGuid>74ac0791-8b1e-4e77-b00c-364cbbeb1a37</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//marquee[@id='mymarquee']/div/div[2]/div[18]/div[2]/div/ul/li</value>
      <webElementGuid>1b293eba-c7ef-42f6-ae0d-fb155839963b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Interview Details: 07 posts of Assistant Public Prosecutor in CBI'])[1]/following::li[2]</value>
      <webElementGuid>5f83e8f9-063f-4e78-9183-21c6b4cd025f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Final Result: 05 Posts of General Duty Medical Officer (Homoeopathy), GNCTD'])[1]/following::li[4]</value>
      <webElementGuid>eb083a78-4fb3-4c4b-a694-0a4d58555d3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Written Result (with name): National Defence Academy and Naval Academy Examination (I), 2024'])[1]/preceding::li[1]</value>
      <webElementGuid>f97e82fa-a78f-4d60-bb68-30cb31de7b86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examination Time Table: Indian Economic Service - Indian Statistical Service Examination, 2024'])[1]/preceding::li[2]</value>
      <webElementGuid>23f2672f-be26-4d8d-b50c-9ce2ed0c8a15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[18]/div[2]/div/ul/li</value>
      <webElementGuid>2d186eef-07ad-4e3d-8f60-39d0cd144170</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment' or . = 'Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment')]</value>
      <webElementGuid>3bab2c85-a9f3-4466-bee3-25b45a385c7a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
