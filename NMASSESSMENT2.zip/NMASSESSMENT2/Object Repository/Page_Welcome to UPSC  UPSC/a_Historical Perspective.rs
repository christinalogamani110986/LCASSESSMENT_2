<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Historical Perspective</name>
   <tag></tag>
   <elementGuidId>6a253b8c-9824-4a50-9181-8b33f87d1049</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.first.leaf.fontSize > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[2]/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#main-menu >> internal:role=link[name=&quot;Historical Perspective&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0760de48-7f1b-4320-8c26-c1249f5d80d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/historical-perspective</value>
      <webElementGuid>61b1eee4-842e-49f7-a36b-f28157fc1ae4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Historical Perspective</value>
      <webElementGuid>f2037703-95f5-4e2f-b4a4-31de1932b508</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;expanded dropdown active&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[@class=&quot;first leaf fontSize&quot;]/a[1]</value>
      <webElementGuid>29df4e5a-a210-455a-a834-ff778007a0c1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[2]/ul/li/a</value>
      <webElementGuid>3e3489b0-3b7b-498d-8de6-2662610e0357</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Historical Perspective')]</value>
      <webElementGuid>92344a89-32c2-4097-bf79-d835cabd9223</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/following::a[1]</value>
      <webElementGuid>d60f59ad-22b9-4072-a5cc-a3e1e432825a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Toggle navigation'])[1]/following::a[3]</value>
      <webElementGuid>bed2540c-33cd-44ba-8f0a-20c50644f318</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Constitutional Provisions'])[1]/preceding::a[1]</value>
      <webElementGuid>960c146f-f032-4cc6-acc0-beeb31deafdb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The Commission'])[1]/preceding::a[2]</value>
      <webElementGuid>81cb8071-dca3-4e8a-92c8-56a245d110e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Historical Perspective']/parent::*</value>
      <webElementGuid>f4156a5b-e49f-4dfc-a157-b423dfa505ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/historical-perspective')]</value>
      <webElementGuid>cd706893-8883-4547-8c69-25950045b9de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li/a</value>
      <webElementGuid>e24d74c8-265e-4afa-8d4d-96117b514cfd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/historical-perspective' and (text() = 'Historical Perspective' or . = 'Historical Perspective')]</value>
      <webElementGuid>aeb02307-e616-48c5-83c6-9048f6bd0531</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
