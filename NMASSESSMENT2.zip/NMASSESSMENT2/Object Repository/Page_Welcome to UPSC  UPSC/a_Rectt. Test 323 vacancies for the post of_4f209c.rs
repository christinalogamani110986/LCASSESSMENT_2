<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Rectt. Test 323 vacancies for the post of_4f209c</name>
   <tag></tag>
   <elementGuidId>c427b1ee-97b4-426d-9aec-155777a63fb1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.views-row.views-row-15.views-row-odd > div.views-field.views-field-field-name-of-post-vaccancy > div.field-content > ul.arrows > li > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//marquee[@id='mymarquee']/div/div[2]/div[15]/div[2]/div/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5b388e0d-f078-405f-b777-d1576c195be0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>whats-new/323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment/Rectt. Test</value>
      <webElementGuid>c60b2491-f1f1-46d8-8c70-3e100257960c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment</value>
      <webElementGuid>11869428-0b9c-4098-9119-df44317b416a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html front not-logged-in two-sidebars page-node i18n-en&quot;]/header[1]/section[@class=&quot;slider-section&quot;]/div[@class=&quot;whats-new fontSize&quot;]/div[@class=&quot;whats-new-marq&quot;]/marquee[@id=&quot;mymarquee&quot;]/div[@class=&quot;view view-what-new view-id-what_new view-display-id-block view-what-new view-dom-id-ea1ed6dea60532fd72a6c69b0b8f1f51&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;views-row views-row-15 views-row-odd&quot;]/div[@class=&quot;views-field views-field-field-name-of-post-vaccancy&quot;]/div[@class=&quot;field-content&quot;]/ul[@class=&quot;arrows&quot;]/li[1]/a[1]</value>
      <webElementGuid>2487007a-8ca6-410a-a580-97f8b8098b4e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//marquee[@id='mymarquee']/div/div[2]/div[15]/div[2]/div/ul/li/a</value>
      <webElementGuid>d7098e53-af4d-4a99-9e39-18d7ee8e66d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment')]</value>
      <webElementGuid>b08483dc-409d-461d-88d8-ccb576aab09e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Final Result: 05 Posts of General Duty Medical Officer (Homoeopathy), GNCTD'])[1]/following::a[1]</value>
      <webElementGuid>e4f908ca-b106-4928-a965-1c6ea07a203b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notice: 12 Posts of Prosecutor in Serious Fraud Investigation Office'])[1]/following::a[2]</value>
      <webElementGuid>73f74589-2081-4906-bd8a-decc5d202a29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Interview Details: 07 posts of Assistant Public Prosecutor in CBI'])[1]/preceding::a[1]</value>
      <webElementGuid>2e92bf24-c501-4602-b345-465d8f76731c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Written Result (with name): National Defence Academy and Naval Academy Examination (I), 2024'])[1]/preceding::a[4]</value>
      <webElementGuid>8fa7c003-58c7-4f59-a818-013f57c14d58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment']/parent::*</value>
      <webElementGuid>b163701c-bf23-4f55-9ac3-19a4c075e2a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'whats-new/323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment/Rectt. Test')]</value>
      <webElementGuid>5b55b20d-fd97-45a9-bfc8-5017c1b9adac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[15]/div[2]/div/ul/li/a</value>
      <webElementGuid>72d22762-d711-4189-9e48-4792f54243be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'whats-new/323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment/Rectt. Test' and (text() = 'Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment' or . = 'Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment')]</value>
      <webElementGuid>a2bd5100-66bd-4ed2-b1e8-91cc99f02bb8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
