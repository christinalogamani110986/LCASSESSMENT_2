<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Press Note Indian Economic Service - In_d1170a</name>
   <tag></tag>
   <elementGuidId>7716e6fa-d80a-4b66-9e60-8c6ff8eac600</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.view.view-what-new.view-id-what_new.view-display-id-block.view-what-new.view-dom-id-ea1ed6dea60532fd72a6c69b0b8f1f51 > div.view-content</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//marquee[@id='mymarquee']/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;Press Note: Indian Economic Service - Indian Statistical Service Examination, 20&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0372c275-e31f-4c28-9a30-263187ea0dd8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>view-content</value>
      <webElementGuid>8dd73bdc-cf42-46ab-adfe-80b04f048a12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
      
              
              
          Press Note: Indian Economic Service - Indian Statistical Service Examination, 2024    
  
      
              
              
          e - Admit Card: Indian Statistical Service Examination, 2024    
  
      
              
              
          e - Admit Card: Indian Economic Service Examination, 2024    
  
      
              
              
          e - Admit Card: Combined Geo-Scientist (Main) Examination, 2024    
  
      
              
              
          Notice: Engineering Services (Main) Examination, 2024    
  
      
              
              
          e - Admit Card: Engineering Services (Main) Examination, 2024    
  
      
              
          Interview Details: 05 Posts of Assistant Professor - Lecturer (Homoeopathic Pharmacy), GNCTD    
              
  
      
              
              
          Press Note: Civil Services (Preliminary) Examination, 2024    
  
      
              
              
          e - Admit Card: Civil Services (Preliminary) Examination, 2024    
  
      
              
          Notice: 76 posts of Junior Translation Officer in ESIC, Min. of Labour and Employment    
              
  
      
              
          Notice: 13 Posts of Assistant Director (Corporate Law) in Serious Fraud Investigation Office    
              
  
      
              
          Notice: 67 Posts of Deputy Superintending Archaeologist, Ministry of Culture    
              
  
      
              
          Notice: 12 Posts of Prosecutor in Serious Fraud Investigation Office    
              
  
      
              
          Final Result: 05 Posts of General Duty Medical Officer (Homoeopathy), GNCTD    
              
  
      
              
          Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment    
              
  
      
              
          Interview Details: 07 posts of Assistant Public Prosecutor in CBI    
              
  
      
              
          Rectt. Test: 1930 vacancies for the post of Nursing Officer in ESIC, Ministry of Labour and Employment    
              
  
      
              
          Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment    
              
  
      
              
              
          Written Result (with name): National Defence Academy and Naval Academy Examination (I), 2024    
  
      
              
              
          Examination Time Table: Indian Economic Service - Indian Statistical Service Examination, 2024    
  
      
              
              
          Examination Time Table: Combined Medical Services Examination, 2024    
  
      
              
          Final Result: 58 Posts of Junior Engineer (Civil), ESIC    
              
  
      
              
          Final Result: 25 Posts of Drug Inspector in Drugs Control Department, GNCTD    
              
  
      
              
          Interview Details: 159 Posts of Assistant Provident Fund Commissioner in EPFO    
              
  
      
              
              
          Marks of Recommended Candidates: Indian Forest Service (Main) Examination, 2023    
  
      
              
          Notice: 05 Posts of Assistant Professor - Lecturer (Homoeopathic Pharmacy), GNCTD    
              
  
      
              
              
          Interview Schedule: Central Armed Police Forces (ACs) Examination, 2023    
  
      
              
              
          Examination Time Table: Combined Geo-Scientist (Main) Examination, 2024    
  
      
              
              
          Examination Time Table: Engineering Services (Main) Examination, 2024    
  
      
              
          Lateral Recruitments: 01 Post of Joint Secretary (Cyber Law), Ministry of Law and Justice    
              
    </value>
      <webElementGuid>a8bf4f2f-25ad-4e01-b149-2a61bd395747</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html front not-logged-in two-sidebars page-node i18n-en&quot;]/header[1]/section[@class=&quot;slider-section&quot;]/div[@class=&quot;whats-new fontSize&quot;]/div[@class=&quot;whats-new-marq&quot;]/marquee[@id=&quot;mymarquee&quot;]/div[@class=&quot;view view-what-new view-id-what_new view-display-id-block view-what-new view-dom-id-ea1ed6dea60532fd72a6c69b0b8f1f51&quot;]/div[@class=&quot;view-content&quot;]</value>
      <webElementGuid>b7563aaf-8866-40be-aef4-2ee6c49e48e3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//marquee[@id='mymarquee']/div/div[2]</value>
      <webElementGuid>9e62c8b6-4f29-4ff9-8346-db5302c71891</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Common mistakes done while filling OMR Sheet/Scannable Attendance List'])[1]/following::div[1]</value>
      <webElementGuid>a14cdb79-4d33-4965-8024-83a7b81d4324</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='What’s New'])[1]/following::div[7]</value>
      <webElementGuid>c49d4296-f708-42a3-ba21-11dae7f62da8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//marquee/div/div[2]</value>
      <webElementGuid>c43f571e-1d72-42ed-be0b-645946be9c43</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
      
              
              
          Press Note: Indian Economic Service - Indian Statistical Service Examination, 2024    
  
      
              
              
          e - Admit Card: Indian Statistical Service Examination, 2024    
  
      
              
              
          e - Admit Card: Indian Economic Service Examination, 2024    
  
      
              
              
          e - Admit Card: Combined Geo-Scientist (Main) Examination, 2024    
  
      
              
              
          Notice: Engineering Services (Main) Examination, 2024    
  
      
              
              
          e - Admit Card: Engineering Services (Main) Examination, 2024    
  
      
              
          Interview Details: 05 Posts of Assistant Professor - Lecturer (Homoeopathic Pharmacy), GNCTD    
              
  
      
              
              
          Press Note: Civil Services (Preliminary) Examination, 2024    
  
      
              
              
          e - Admit Card: Civil Services (Preliminary) Examination, 2024    
  
      
              
          Notice: 76 posts of Junior Translation Officer in ESIC, Min. of Labour and Employment    
              
  
      
              
          Notice: 13 Posts of Assistant Director (Corporate Law) in Serious Fraud Investigation Office    
              
  
      
              
          Notice: 67 Posts of Deputy Superintending Archaeologist, Ministry of Culture    
              
  
      
              
          Notice: 12 Posts of Prosecutor in Serious Fraud Investigation Office    
              
  
      
              
          Final Result: 05 Posts of General Duty Medical Officer (Homoeopathy), GNCTD    
              
  
      
              
          Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment    
              
  
      
              
          Interview Details: 07 posts of Assistant Public Prosecutor in CBI    
              
  
      
              
          Rectt. Test: 1930 vacancies for the post of Nursing Officer in ESIC, Ministry of Labour and Employment    
              
  
      
              
          Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment    
              
  
      
              
              
          Written Result (with name): National Defence Academy and Naval Academy Examination (I), 2024    
  
      
              
              
          Examination Time Table: Indian Economic Service - Indian Statistical Service Examination, 2024    
  
      
              
              
          Examination Time Table: Combined Medical Services Examination, 2024    
  
      
              
          Final Result: 58 Posts of Junior Engineer (Civil), ESIC    
              
  
      
              
          Final Result: 25 Posts of Drug Inspector in Drugs Control Department, GNCTD    
              
  
      
              
          Interview Details: 159 Posts of Assistant Provident Fund Commissioner in EPFO    
              
  
      
              
              
          Marks of Recommended Candidates: Indian Forest Service (Main) Examination, 2023    
  
      
              
          Notice: 05 Posts of Assistant Professor - Lecturer (Homoeopathic Pharmacy), GNCTD    
              
  
      
              
              
          Interview Schedule: Central Armed Police Forces (ACs) Examination, 2023    
  
      
              
              
          Examination Time Table: Combined Geo-Scientist (Main) Examination, 2024    
  
      
              
              
          Examination Time Table: Engineering Services (Main) Examination, 2024    
  
      
              
          Lateral Recruitments: 01 Post of Joint Secretary (Cyber Law), Ministry of Law and Justice    
              
    ' or . = '
        
      
              
              
          Press Note: Indian Economic Service - Indian Statistical Service Examination, 2024    
  
      
              
              
          e - Admit Card: Indian Statistical Service Examination, 2024    
  
      
              
              
          e - Admit Card: Indian Economic Service Examination, 2024    
  
      
              
              
          e - Admit Card: Combined Geo-Scientist (Main) Examination, 2024    
  
      
              
              
          Notice: Engineering Services (Main) Examination, 2024    
  
      
              
              
          e - Admit Card: Engineering Services (Main) Examination, 2024    
  
      
              
          Interview Details: 05 Posts of Assistant Professor - Lecturer (Homoeopathic Pharmacy), GNCTD    
              
  
      
              
              
          Press Note: Civil Services (Preliminary) Examination, 2024    
  
      
              
              
          e - Admit Card: Civil Services (Preliminary) Examination, 2024    
  
      
              
          Notice: 76 posts of Junior Translation Officer in ESIC, Min. of Labour and Employment    
              
  
      
              
          Notice: 13 Posts of Assistant Director (Corporate Law) in Serious Fraud Investigation Office    
              
  
      
              
          Notice: 67 Posts of Deputy Superintending Archaeologist, Ministry of Culture    
              
  
      
              
          Notice: 12 Posts of Prosecutor in Serious Fraud Investigation Office    
              
  
      
              
          Final Result: 05 Posts of General Duty Medical Officer (Homoeopathy), GNCTD    
              
  
      
              
          Rectt. Test: 323 vacancies for the post of Personal Assistant in EPFO, Ministry of Labour and Employment    
              
  
      
              
          Interview Details: 07 posts of Assistant Public Prosecutor in CBI    
              
  
      
              
          Rectt. Test: 1930 vacancies for the post of Nursing Officer in ESIC, Ministry of Labour and Employment    
              
  
      
              
          Interview Details: 42 Posts of Labour Enforcement Officer (Central), Ministry of Labour and Employment    
              
  
      
              
              
          Written Result (with name): National Defence Academy and Naval Academy Examination (I), 2024    
  
      
              
              
          Examination Time Table: Indian Economic Service - Indian Statistical Service Examination, 2024    
  
      
              
              
          Examination Time Table: Combined Medical Services Examination, 2024    
  
      
              
          Final Result: 58 Posts of Junior Engineer (Civil), ESIC    
              
  
      
              
          Final Result: 25 Posts of Drug Inspector in Drugs Control Department, GNCTD    
              
  
      
              
          Interview Details: 159 Posts of Assistant Provident Fund Commissioner in EPFO    
              
  
      
              
              
          Marks of Recommended Candidates: Indian Forest Service (Main) Examination, 2023    
  
      
              
          Notice: 05 Posts of Assistant Professor - Lecturer (Homoeopathic Pharmacy), GNCTD    
              
  
      
              
              
          Interview Schedule: Central Armed Police Forces (ACs) Examination, 2023    
  
      
              
              
          Examination Time Table: Combined Geo-Scientist (Main) Examination, 2024    
  
      
              
              
          Examination Time Table: Engineering Services (Main) Examination, 2024    
  
      
              
          Lateral Recruitments: 01 Post of Joint Secretary (Cyber Law), Ministry of Law and Justice    
              
    ')]</value>
      <webElementGuid>e9071282-285b-4af8-8c55-cbf5c0a79945</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
