<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_View all</name>
   <tag></tag>
   <elementGuidId>12c73a15-b173-430d-909a-86b4b4b42836</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.view.view-exams.view-id-exams.view-display-id-block_2.view-dom-id-bfe801c86c877d7dd0505d4ed9e5de92 > div.more-link > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-views-exams-block-2']/div/div[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;View all >>&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>71e6cc57-493b-4458-9742-59c262de50f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/examinations/forthcoming-exams</value>
      <webElementGuid>c71515d1-7148-4f2d-a388-e9d20882000d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    View all >>  </value>
      <webElementGuid>33e95bf1-c824-4da9-9b6c-a7c98d289bf5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-views-exams-block-2&quot;)/div[@class=&quot;view view-exams view-id-exams view-display-id-block_2 view-dom-id-bfe801c86c877d7dd0505d4ed9e5de92&quot;]/div[@class=&quot;more-link&quot;]/a[1]</value>
      <webElementGuid>68c7a86e-798f-45bc-98d1-c82e061bd4e8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-views-exams-block-2']/div/div[2]/a</value>
      <webElementGuid>4407d603-49dd-450d-bebc-193e84404106</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'View all >>')]</value>
      <webElementGuid>54f89ec0-d278-4869-89de-e0813b64d727</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Combined Geo-Scientist (Preliminary) Examination, 2025'])[1]/following::a[1]</value>
      <webElementGuid>3f8023b9-5e00-44ea-ad5b-53b92ba5d69c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SO - Steno (GD-B-GD-I) LDCE'])[1]/following::a[2]</value>
      <webElementGuid>e7eb1fe9-8c94-4c18-aa96-197e4f6c1107</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment'])[2]/preceding::a[1]</value>
      <webElementGuid>cf488c19-57c7-491a-9cca-c30efc57b2d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Advertisements'])[2]/preceding::a[1]</value>
      <webElementGuid>3dbcaaa0-57e0-485c-be86-b2df2f806eae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='View all >>']/parent::*</value>
      <webElementGuid>0deeb82b-1e6c-46e8-8c30-51d2eb66b965</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/examinations/forthcoming-exams')])[2]</value>
      <webElementGuid>ade82f7f-ccdd-4004-8cb4-71563ff78f09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[3]/div/div[2]/a</value>
      <webElementGuid>2ef08bdc-99a6-4070-855c-fe4cab912280</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/examinations/forthcoming-exams' and (text() = '
    View all >>  ' or . = '
    View all >>  ')]</value>
      <webElementGuid>2173a779-10d3-4b7f-88fb-5c2ea86755b1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
