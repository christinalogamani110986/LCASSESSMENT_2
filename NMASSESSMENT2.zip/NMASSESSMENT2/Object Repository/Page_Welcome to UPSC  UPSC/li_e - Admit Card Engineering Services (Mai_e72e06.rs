<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_e - Admit Card Engineering Services (Mai_e72e06</name>
   <tag></tag>
   <elementGuidId>f552bf34-bc88-4dc2-8a07-1cc04d1e909d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.views-row.views-row-6.views-row-even > span.views-field.views-field-field-exam-name > span.field-content > a > ul.arrows > li</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//marquee[@id='mymarquee']/div/div[2]/div[6]/span/span/a/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;»e - Admit Card: Engineering Services (Main) Examination, 2024&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>58cc2823-774f-46a4-aaf1-d8248fe4db55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>e - Admit Card: Engineering Services (Main) Examination, 2024</value>
      <webElementGuid>a91da1b2-7b8a-430c-8760-cac58b8be500</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html front not-logged-in two-sidebars page-node i18n-en&quot;]/header[1]/section[@class=&quot;slider-section&quot;]/div[@class=&quot;whats-new fontSize&quot;]/div[@class=&quot;whats-new-marq&quot;]/marquee[@id=&quot;mymarquee&quot;]/div[@class=&quot;view view-what-new view-id-what_new view-display-id-block view-what-new view-dom-id-ea1ed6dea60532fd72a6c69b0b8f1f51&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;views-row views-row-6 views-row-even&quot;]/span[@class=&quot;views-field views-field-field-exam-name&quot;]/span[@class=&quot;field-content&quot;]/a[1]/ul[@class=&quot;arrows&quot;]/li[1]</value>
      <webElementGuid>2792ce0e-837f-4c11-b8a6-9ee037b63da6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//marquee[@id='mymarquee']/div/div[2]/div[6]/span/span/a/ul/li</value>
      <webElementGuid>6a6c9fd2-fd4c-4791-bbf4-3798f2d74c10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notice: Engineering Services (Main) Examination, 2024'])[1]/following::li[1]</value>
      <webElementGuid>72bde1bc-3d59-445d-9ff0-f8ecc45b967e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='e - Admit Card: Combined Geo-Scientist (Main) Examination, 2024'])[1]/following::li[2]</value>
      <webElementGuid>3a9861ac-7b1a-444c-82e0-8c66eb848272</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Interview Details: 05 Posts of Assistant Professor - Lecturer (Homoeopathic Pharmacy), GNCTD'])[1]/preceding::li[1]</value>
      <webElementGuid>f4021291-0d3a-436d-96f6-db39c833682d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Press Note: Civil Services (Preliminary) Examination, 2024'])[1]/preceding::li[2]</value>
      <webElementGuid>a9305002-521a-4341-bc75-dcdba124ed09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='e - Admit Card: Engineering Services (Main) Examination, 2024']/parent::*</value>
      <webElementGuid>086e99f8-9c2a-489c-a1bf-dfad54e25084</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/span/span/a/ul/li</value>
      <webElementGuid>fe49edd0-7e5c-4c67-9172-129f8e677307</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'e - Admit Card: Engineering Services (Main) Examination, 2024' or . = 'e - Admit Card: Engineering Services (Main) Examination, 2024')]</value>
      <webElementGuid>73ed4d78-2d73-4a34-9767-5a237cadcdf5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
