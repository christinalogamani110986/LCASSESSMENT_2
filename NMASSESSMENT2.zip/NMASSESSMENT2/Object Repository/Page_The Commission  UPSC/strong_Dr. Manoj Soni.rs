<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Dr. Manoj Soni</name>
   <tag></tag>
   <elementGuidId>3d36b08b-3332-4193-a59c-3621b0e853ed</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p > a > strong</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-views-basic-page-block']/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/p/a/strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Dr. Manoj Soni&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>3791d3db-18a1-4140-b562-42c17645fc5d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Dr. Manoj Soni</value>
      <webElementGuid>fafc7320-8530-4e71-8077-b6ca495404a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-views-basic-page-block&quot;)/div[@class=&quot;view view-basic-page view-id-basic_page view-display-id-block view-dom-id-e4fc7988e96f64963486d7bb2b86d896&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;views-row views-row-1 views-row-odd views-row-first views-row-last&quot;]/div[@class=&quot;views-field views-field-body&quot;]/div[@class=&quot;field-content&quot;]/div[@class=&quot;scroll-table1&quot;]/table[1]/tbody[1]/tr[2]/td[2]/p[1]/a[1]/strong[1]</value>
      <webElementGuid>deb7876e-09ac-4890-913d-80e3aefe2815</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-views-basic-page-block']/div/div/div/div/div/div[2]/table/tbody/tr[2]/td[2]/p/a/strong</value>
      <webElementGuid>48b87681-39f7-4552-a4fb-f3eac4ea1364</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chairman'])[1]/following::strong[1]</value>
      <webElementGuid>6a66ea40-1575-49f3-b6bc-dd49f1bdea94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Date of retirement'])[1]/following::strong[2]</value>
      <webElementGuid>93b995f0-2327-491c-96b2-6eea75858a2a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Member'])[1]/preceding::strong[4]</value>
      <webElementGuid>e2af5c35-1a44-4287-82f6-66782d597c08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lt. Gen. Raj Shukla (Retd.)'])[1]/preceding::strong[5]</value>
      <webElementGuid>955fb3ca-e184-4bc5-8f5c-4a47e851dbb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Dr. Manoj Soni']/parent::*</value>
      <webElementGuid>6d593822-b504-4e74-b7ea-d3382950bcbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/a/strong</value>
      <webElementGuid>81c19d7b-26e6-488b-8dd0-788186f7352b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Dr. Manoj Soni' or . = 'Dr. Manoj Soni')]</value>
      <webElementGuid>277fc372-7718-4b92-bec3-fd1f8b8de579</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
