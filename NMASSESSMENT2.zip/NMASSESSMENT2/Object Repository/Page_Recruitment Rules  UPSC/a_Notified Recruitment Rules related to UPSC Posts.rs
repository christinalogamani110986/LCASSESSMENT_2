<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Notified Recruitment Rules related to UPSC Posts</name>
   <tag></tag>
   <elementGuidId>a0afb143-def4-4b90-85b6-dcfaa0ce51fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.last.leaf.menu-mlid-1616 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-3']/div/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Notified Recruitment Rules related to UPSC Posts&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>20335582-a51b-4330-83d4-1ae20afcbba3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/divisions/administration/recruitment-rules/notified-recruitment-rules</value>
      <webElementGuid>a0529607-2b04-442b-8206-3b3ecd027ff0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Notified Recruitment Rules related to UPSC Posts</value>
      <webElementGuid>16966d22-df81-48bb-bd98-ca784c74a992</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-3&quot;)/div[@class=&quot;menu-block-wrapper menu-block-3 menu-name-main-menu parent-mlid-0 menu-level-3&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;last leaf menu-mlid-1616&quot;]/a[1]</value>
      <webElementGuid>4c154265-e1d4-4e89-9969-574104c73bf1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-3']/div/ul/li[2]/a</value>
      <webElementGuid>19ca83aa-4f43-4333-974b-30df64c1c174</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Notified Recruitment Rules related to UPSC Posts')]</value>
      <webElementGuid>fdffc4fe-aba2-4887-8769-f3fc042ef68e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Draft Recruitment Rules of UPSC'])[1]/following::a[1]</value>
      <webElementGuid>0c056374-d5e9-4b1b-98d9-f5d51770b4a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Rules'])[3]/following::a[2]</value>
      <webElementGuid>3eb25eb6-6f39-48bd-80db-106ca2641fbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='हिन्दी'])[2]/preceding::a[1]</value>
      <webElementGuid>c3da26ac-0242-413a-a585-cf1e02adc677</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Website Policies'])[1]/preceding::a[2]</value>
      <webElementGuid>2df11cc4-a01a-43da-87dc-d083d8217b2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Notified Recruitment Rules related to UPSC Posts']/parent::*</value>
      <webElementGuid>f8759d41-4899-4cea-a856-13adb967a69b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/divisions/administration/recruitment-rules/notified-recruitment-rules')]</value>
      <webElementGuid>ca2de953-aa0f-4fac-97e2-d5652aea2939</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/ul/li[2]/a</value>
      <webElementGuid>3a1d9043-e2e8-4069-bfa5-dde2b35d903a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/divisions/administration/recruitment-rules/notified-recruitment-rules' and (text() = 'Notified Recruitment Rules related to UPSC Posts' or . = 'Notified Recruitment Rules related to UPSC Posts')]</value>
      <webElementGuid>c9103d67-f59d-4ddc-bfc8-fdda8306b006</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
