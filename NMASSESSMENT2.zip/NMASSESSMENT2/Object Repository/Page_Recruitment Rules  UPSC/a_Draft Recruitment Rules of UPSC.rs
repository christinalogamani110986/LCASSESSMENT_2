<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Draft Recruitment Rules of UPSC</name>
   <tag></tag>
   <elementGuidId>bb919746-87cf-4155-b829-702b179aadc6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.first.leaf.menu-mlid-1671 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-3']/div/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Draft Recruitment Rules of UPSC&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>893b8b14-be33-4778-ad85-a38351f9933e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/divisions/administration/recruitment-rules/draft-recruitment-rules-for-upsc</value>
      <webElementGuid>2287368a-bfd2-42a9-8c86-1e53c5ddeefa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Draft Recruitment Rules of UPSC</value>
      <webElementGuid>04341ac8-7f9d-4a03-97c5-b03d4ce3b269</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-3&quot;)/div[@class=&quot;menu-block-wrapper menu-block-3 menu-name-main-menu parent-mlid-0 menu-level-3&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;first leaf menu-mlid-1671&quot;]/a[1]</value>
      <webElementGuid>b79b3730-15a6-4373-86ce-6db88bb12865</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-3']/div/ul/li/a</value>
      <webElementGuid>bd76761f-800d-41a9-8ba4-f2cdee697625</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Draft Recruitment Rules of UPSC')]</value>
      <webElementGuid>73434a5d-1cd6-4546-83a3-4cca38d4c72f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Rules'])[3]/following::a[1]</value>
      <webElementGuid>5aa72258-9e44-4e2f-be30-820b42ae4921</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Work with Us'])[1]/following::a[2]</value>
      <webElementGuid>8cd9a941-e18f-465c-b7ea-3ebea59e81c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notified Recruitment Rules related to UPSC Posts'])[1]/preceding::a[1]</value>
      <webElementGuid>1b91077a-f212-48d8-ad64-7cde40aed5a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='हिन्दी'])[2]/preceding::a[2]</value>
      <webElementGuid>04560c6d-448b-4191-9ade-b2d99959b5e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Draft Recruitment Rules of UPSC']/parent::*</value>
      <webElementGuid>f776ec2e-ce11-43ec-8bd1-1dd4f66d338c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/divisions/administration/recruitment-rules/draft-recruitment-rules-for-upsc')]</value>
      <webElementGuid>a242e648-6c25-4eeb-b86b-9e300d14ed06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/ul/li/a</value>
      <webElementGuid>a81a479e-16b6-4537-ba4b-9020ab9b5e92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/divisions/administration/recruitment-rules/draft-recruitment-rules-for-upsc' and (text() = 'Draft Recruitment Rules of UPSC' or . = 'Draft Recruitment Rules of UPSC')]</value>
      <webElementGuid>2aaaa426-da58-4c09-aa96-049ec2e019e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
