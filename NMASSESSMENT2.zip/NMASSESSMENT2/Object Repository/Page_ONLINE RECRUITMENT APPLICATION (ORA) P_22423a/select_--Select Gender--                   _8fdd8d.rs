<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_--Select Gender--                   _8fdd8d</name>
   <tag></tag>
   <elementGuidId>78a51281-ae01-4d79-9121-789e8c8bfbbf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#sex</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='sex']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#sex</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>1f2545e3-f471-4fbe-8693-5d08facc3763</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>sex</value>
      <webElementGuid>e0f0e24a-eacc-42b9-9a30-3b8509f8bfdb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>sex</value>
      <webElementGuid>2e826609-9c64-47de-a3e7-94ed71fe43e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>changefees(this.value)</value>
      <webElementGuid>c430ccaf-b209-4261-9790-5b6c9a295a8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    --Select Gender--
                                                    Male
                                                    Female
                                                    
													Transgender
													
                                                </value>
      <webElementGuid>0cab0bc3-2170-494a-be60-3013266799f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sex&quot;)</value>
      <webElementGuid>b2b35f05-ec5e-4470-acac-69cf131eb217</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='sex']</value>
      <webElementGuid>937299ba-0226-4161-87ce-642172db813f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='test']/div/table/tbody/tr[4]/td[2]/select</value>
      <webElementGuid>f3fa250d-fa66-45b5-8e21-d979adc455e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='लिंग / Gender'])[1]/following::select[1]</value>
      <webElementGuid>02d59794-7509-4792-9169-e952b965d0e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='समुदाय / Community'])[1]/preceding::select[1]</value>
      <webElementGuid>fee345ed-a7e1-47eb-9bca-4b32a189b5c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>18d8558b-773e-4c48-bf65-7c44bef47cb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'sex' and @id = 'sex' and (text() = '
                                                    --Select Gender--
                                                    Male
                                                    Female
                                                    
													Transgender
													
                                                ' or . = '
                                                    --Select Gender--
                                                    Male
                                                    Female
                                                    
													Transgender
													
                                                ')]</value>
      <webElementGuid>c78b37d0-25a5-4f8a-95e2-2c7b9f3eb1c5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
