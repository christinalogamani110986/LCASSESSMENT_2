<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_The Commission</name>
   <tag></tag>
   <elementGuidId>a12e7840-6fca-4832-9277-8fa75c95af8c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[2]/ul/li[3]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;The Commission&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7f74fe66-72d4-45a8-b79e-4b19dafc7756</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/commission-</value>
      <webElementGuid>a9dc636d-5e03-412b-ac1d-2271d81d1554</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>The Commission</value>
      <webElementGuid>5d2d8cbc-dc30-44bb-a4e0-6e10ce7ac3de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;expanded active-trail dropdown&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[@class=&quot;leaf fontSize&quot;]/a[1]</value>
      <webElementGuid>0e42c686-c5fc-4f17-a007-e58f3a02b462</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[2]/ul/li[3]/a</value>
      <webElementGuid>86638d22-4776-4b23-992b-a81d6c16d239</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'The Commission')]</value>
      <webElementGuid>21e9dcaf-77d1-471c-b5ad-53862051bc32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Constitutional Provisions'])[1]/following::a[1]</value>
      <webElementGuid>7e38d437-7e3b-4942-8ba0-5f1e02b95e05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Historical Perspective'])[1]/following::a[2]</value>
      <webElementGuid>59eb3a8c-04cb-4047-9c58-914e01b8c561</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Functions'])[1]/preceding::a[1]</value>
      <webElementGuid>cfead75e-47ac-441b-b6ef-90b546bbed41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secretariat'])[1]/preceding::a[2]</value>
      <webElementGuid>1ab3c045-c051-40b7-8540-7ebabd507363</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='The Commission']/parent::*</value>
      <webElementGuid>f7929aea-a8e6-45b8-9b98-20ed780d80c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/commission-')]</value>
      <webElementGuid>d4d9e4b3-bf39-461b-9b81-1120b8b323af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[3]/a</value>
      <webElementGuid>173c6af7-da7f-4315-9450-399be3c08317</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/commission-' and (text() = 'The Commission' or . = 'The Commission')]</value>
      <webElementGuid>31387163-24ff-49f2-bf28-a3e4419837b7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
