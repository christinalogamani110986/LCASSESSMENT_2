<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Note No Alphabet , No Special Characte_3e69d5</name>
   <tag></tag>
   <elementGuidId>70e0228a-9827-4b1d-aee1-55f3245bf84a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.note</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='showrollnofrm']/form/table/tbody/tr[2]/td[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;[Note: No Alphabet , No Special Characters , Roll NO Must be 7 Digit] / [टिप्‍पण&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>d2be1e1c-0d46-417e-9ac9-e8fbe3ccdc06</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>note</value>
      <webElementGuid>8a143a2a-f806-4808-a2ca-ea7dfde3a4d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>[Note: No Alphabet , No Special Characters , Roll NO Must be 7 Digit] / 
[टिप्‍पणी  :  कोई वर्ण, कोई अक्षर नहीं,  रोल नं. अनिवार्यत: 7 अंक का हो] </value>
      <webElementGuid>0caaf254-ac25-40ee-92d9-d6f2975b4f05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;showrollnofrm&quot;)/form[1]/table[@class=&quot;front&quot;]/tbody[1]/tr[2]/td[2]/span[@class=&quot;note&quot;]</value>
      <webElementGuid>f7aabf69-c043-41f2-9e96-c5486806aba8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='showrollnofrm']/form/table/tbody/tr[2]/td[2]/span</value>
      <webElementGuid>4534f6a6-1631-4ef2-ab7d-dcd4c9f4151e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter Your Roll Number / अपना रोल नं. एंटर करें'])[1]/following::span[1]</value>
      <webElementGuid>44c7a1cb-9b23-4c13-ae16-2a8b194f468b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='By Roll Number Search / रोल नं. खोजकर'])[1]/following::span[1]</value>
      <webElementGuid>2249b2f5-7c7d-461e-934f-eee66799faa5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='[Note: As Recorded in the Application] / (टिप्‍पणी : आवेदन में दर्ज किए अनुसार)'])[1]/preceding::span[1]</value>
      <webElementGuid>f4952e15-ec30-49f8-9994-e9394c47b47e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/span</value>
      <webElementGuid>fa4de298-f35d-4f48-864f-d45aaeacaad0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '[Note: No Alphabet , No Special Characters , Roll NO Must be 7 Digit] / 
[टिप्‍पणी  :  कोई वर्ण, कोई अक्षर नहीं,  रोल नं. अनिवार्यत: 7 अंक का हो] ' or . = '[Note: No Alphabet , No Special Characters , Roll NO Must be 7 Digit] / 
[टिप्‍पणी  :  कोई वर्ण, कोई अक्षर नहीं,  रोल नं. अनिवार्यत: 7 अंक का हो] ')]</value>
      <webElementGuid>7c20b313-b0de-4ea8-af19-8757207675fb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
