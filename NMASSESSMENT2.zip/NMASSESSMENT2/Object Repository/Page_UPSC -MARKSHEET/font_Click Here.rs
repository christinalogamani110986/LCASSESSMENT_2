<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>font_Click Here</name>
   <tag></tag>
   <elementGuidId>c4d41716-98f7-4253-b02a-bd4617560a27</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a > font</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='INDIAN FOREST SERVICE (MAIN) EXAMINATION'])[1]/following::font[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;1 INDIAN FOREST SERVICE (MAIN) EXAMINATION 2023 16-05-2024 16-06-2024 Click Here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>font</value>
      <webElementGuid>80e01b00-cf16-4473-bf0a-e1c5ac5c36f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>941f7aa2-826c-4fc9-a2cc-c14b59ceff2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[7]/div[@class=&quot;grid&quot;]/table[1]/tbody[1]/tr[2]/td[6]/a[1]/font[1]</value>
      <webElementGuid>248c26a0-667c-407b-866a-eb83ed70e537</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INDIAN FOREST SERVICE (MAIN) EXAMINATION'])[1]/following::font[4]</value>
      <webElementGuid>f919167d-dc56-4b62-8c82-8f9937180f6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='कब तक उपलब्धAvailable Upto'])[1]/following::font[6]</value>
      <webElementGuid>f91a1e4c-f2f3-4f2e-bb67-79e084f3db30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[2]/preceding::font[6]</value>
      <webElementGuid>5a64e18d-2f8a-4135-bf1f-c207fec083be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Archives >>>'])[1]/preceding::font[7]</value>
      <webElementGuid>353eae7f-539a-4c40-aeaf-bff880e04cc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Click Here']/parent::*</value>
      <webElementGuid>0b5868b9-d1bc-42d5-9762-b4dc70a275d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/font</value>
      <webElementGuid>d01fa6bb-4cb0-4994-8d13-26eea4f568c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//font[(text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>cde66169-25be-47f8-8338-397716c9bceb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
