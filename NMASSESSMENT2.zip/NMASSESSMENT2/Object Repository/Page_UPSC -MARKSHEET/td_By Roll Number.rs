<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_By Roll Number</name>
   <tag></tag>
   <elementGuidId>dc9fc971-4497-4953-9ea6-c32b077566af</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(2) > td:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='By Registration Id / पंजीकरण आई डी द्वारा'])[1]/following::td[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;By Roll Number / रोल नं. द्वारा&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>ffccb761-eacd-4277-9987-a1a84fbad5a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>  By Roll Number / रोल नं. द्वारा    </value>
      <webElementGuid>11e0a4d4-7730-4137-9826-914192a98496</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[5]/div[@class=&quot;grid&quot;]/div[@class=&quot;rounded&quot;]/div[@class=&quot;mid-outer&quot;]/div[@class=&quot;mid-inner&quot;]/div[@class=&quot;mid&quot;]/form[1]/table[@class=&quot;front&quot;]/tbody[1]/tr[2]/td[2]</value>
      <webElementGuid>dabeb690-78f8-4b87-a5d8-0cd9b9d8e36e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='By Registration Id / पंजीकरण आई डी द्वारा'])[1]/following::td[1]</value>
      <webElementGuid>687b1473-737c-4fc9-ab05-1110d7c071d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select any of the given option / निम्‍न में से कोई भी विकल्‍प चुनें'])[1]/following::td[2]</value>
      <webElementGuid>73482a1e-df91-42cc-bff5-f912a0409b63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td[2]</value>
      <webElementGuid>07cb5457-bd36-4285-9b24-70c088a79367</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = '  By Roll Number / रोल नं. द्वारा    ' or . = '  By Roll Number / रोल नं. द्वारा    ')]</value>
      <webElementGuid>6814fe0c-85f6-44a5-a0d9-b3433ef29b54</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
