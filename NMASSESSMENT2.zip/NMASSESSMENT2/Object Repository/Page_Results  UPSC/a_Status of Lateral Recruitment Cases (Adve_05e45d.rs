<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Status of Lateral Recruitment Cases (Adve_05e45d</name>
   <tag></tag>
   <elementGuidId>d59273ce-0b0c-43ba-bc2e-26bbe9d10907</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.easy-breadcrumb_segment.easy-breadcrumb_segment-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-easy-breadcrumb-easy-breadcrumb']/div/a[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Status of Lateral Recruitment Cases (Advertisement-wise)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>1f91b38b-c99a-4427-865c-6cd1e49641c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/recruitment/lateral-recruitments</value>
      <webElementGuid>676a9d93-5471-4d13-b07c-018d57ad4311</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>easy-breadcrumb_segment easy-breadcrumb_segment-2</value>
      <webElementGuid>23bcd9ac-72be-4f42-bc6e-05e44ddda70e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Status of Lateral Recruitment Cases (Advertisement-wise)</value>
      <webElementGuid>94f2ef52-25b4-457e-ad26-0f0156b384dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-easy-breadcrumb-easy-breadcrumb&quot;)/div[@class=&quot;easy-breadcrumb&quot;]/a[@class=&quot;easy-breadcrumb_segment easy-breadcrumb_segment-2&quot;]</value>
      <webElementGuid>70887669-aeaf-45d3-9a2e-6d470330696a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-easy-breadcrumb-easy-breadcrumb']/div/a[2]</value>
      <webElementGuid>e2cf9605-40b0-44da-a0a0-67123c8765fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Status of Lateral Recruitment Cases (Advertisement-wise)')])[2]</value>
      <webElementGuid>b0caf14f-f3e9-45a4-98c3-a9870abb8cf0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>>'])[2]/following::a[1]</value>
      <webElementGuid>b864aeda-039f-46b9-b799-aa03518d7777</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment'])[2]/following::a[1]</value>
      <webElementGuid>6e3f2b40-615c-402b-be36-2755a8e9d96b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>>'])[3]/preceding::a[1]</value>
      <webElementGuid>7a29dff6-bea7-408a-938c-ad2efc64de9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Results'])[1]/preceding::a[1]</value>
      <webElementGuid>7a302fe8-865f-4a7e-98cd-8a7a5e3b73cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/recruitment/lateral-recruitments')])[3]</value>
      <webElementGuid>e222a985-55d5-4ec0-9f1a-8b7778b5ab93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[2]</value>
      <webElementGuid>606c139d-cb3d-48dd-8dad-fd9f0de1bc84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/recruitment/lateral-recruitments' and (text() = 'Status of Lateral Recruitment Cases (Advertisement-wise)' or . = 'Status of Lateral Recruitment Cases (Advertisement-wise)')]</value>
      <webElementGuid>f84aaff9-cdca-4409-b7b8-ba18405c701b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
