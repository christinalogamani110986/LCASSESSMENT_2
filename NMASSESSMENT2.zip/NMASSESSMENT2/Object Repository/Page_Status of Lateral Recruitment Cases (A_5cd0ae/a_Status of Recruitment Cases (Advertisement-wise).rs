<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Status of Recruitment Cases (Advertisement-wise)</name>
   <tag></tag>
   <elementGuidId>7522a841-6e97-4667-b3f3-3e37b334d92b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.has-children.menu-mlid-1371 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[4]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Status of Recruitment Cases (Advertisement-wise)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>51576331-d881-4c6e-bca3-0193c40f3d1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/recruitment/status-recruitment-cases-advertisementwise</value>
      <webElementGuid>23accdd5-7578-4aac-a9d2-0f08b91e9162</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Status of Recruitment Cases (Advertisement-wise)</value>
      <webElementGuid>db790506-a370-4827-a4a8-49aee05094ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf has-children menu-mlid-1371&quot;]/a[1]</value>
      <webElementGuid>de5cc1a1-8bd0-4d9e-9c75-cab970e2c273</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[4]/a</value>
      <webElementGuid>25d79f75-4db6-48b5-8c66-6c462603921c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Status of Recruitment Cases (Advertisement-wise)')])[2]</value>
      <webElementGuid>ff4b3835-f69f-4ef3-83fc-f0f344545dca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Recruitment Application (ORA)'])[2]/following::a[1]</value>
      <webElementGuid>ea3e0e1e-61ff-4ebf-8695-c1ad2f95c56e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status of Lateral Recruitment Cases (Advertisement-wise)'])[3]/following::a[2]</value>
      <webElementGuid>209d176d-d40b-407e-8eb1-adf8df8acb33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forms for Certificates'])[2]/preceding::a[1]</value>
      <webElementGuid>09c62c9c-7e73-4115-8a0f-a8e0408bcae4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Tests'])[2]/preceding::a[2]</value>
      <webElementGuid>4ff3dbf2-7d2f-43fb-8dfe-b498f8a21618</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/recruitment/status-recruitment-cases-advertisementwise')])[2]</value>
      <webElementGuid>9b18f86c-3f3f-411b-b6e3-3092d902c087</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[4]/a</value>
      <webElementGuid>9c4ad405-1442-449b-8e30-8e229b969995</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/recruitment/status-recruitment-cases-advertisementwise' and (text() = 'Status of Recruitment Cases (Advertisement-wise)' or . = 'Status of Recruitment Cases (Advertisement-wise)')]</value>
      <webElementGuid>e3fd49e5-7b1a-4bef-9b96-cf45c60240e9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
