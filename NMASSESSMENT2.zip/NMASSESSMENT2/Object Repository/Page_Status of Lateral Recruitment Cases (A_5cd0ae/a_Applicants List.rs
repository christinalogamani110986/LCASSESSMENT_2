<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Applicants List</name>
   <tag></tag>
   <elementGuidId>573b7455-f904-4686-b4d7-48b7634b68ea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.first.leaf.menu-mlid-3234 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-3']/div/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Applicants' List&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cede857a-de12-42e0-ba6a-e7cf190fe64b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/recruitment/lateral-recruitments/applicant-list</value>
      <webElementGuid>90f5ee28-a552-4038-b327-9b028bb723e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Applicants' List</value>
      <webElementGuid>22bb598e-86e5-49f5-b784-d99185f1a773</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-3&quot;)/div[@class=&quot;menu-block-wrapper menu-block-3 menu-name-main-menu parent-mlid-0 menu-level-3&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;first leaf menu-mlid-3234&quot;]/a[1]</value>
      <webElementGuid>023fe2bd-3138-491d-ae35-19f501ce9f20</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-3']/div/ul/li/a</value>
      <webElementGuid>7178523a-e905-4c23-a2f9-dbf07f1e0ef2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status of Lateral Recruitment Cases (Advertisement-wise)'])[4]/following::a[1]</value>
      <webElementGuid>79855b7e-ab9c-4fc6-a042-6bc6987cbdaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Representation on Question Papers'])[3]/following::a[2]</value>
      <webElementGuid>1a45a0fb-ba5c-4b77-91b7-f3899912834f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notices'])[1]/preceding::a[1]</value>
      <webElementGuid>19fc90a2-75c0-42ca-bc97-bedd9538d711</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Corrigendum'])[1]/preceding::a[2]</value>
      <webElementGuid>4b6e5c7a-c319-4d36-a52f-3751276b1220</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/recruitment/lateral-recruitments/applicant-list')]</value>
      <webElementGuid>5af511f2-7d16-4162-a29e-1d1ad8d7600f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/ul/li/a</value>
      <webElementGuid>c8dc4959-9350-4907-afbe-746674418f98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/recruitment/lateral-recruitments/applicant-list' and (text() = concat(&quot;Applicants&quot; , &quot;'&quot; , &quot; List&quot;) or . = concat(&quot;Applicants&quot; , &quot;'&quot; , &quot; List&quot;))]</value>
      <webElementGuid>937b5307-24e3-4e80-a253-27fc25d470b9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
