<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_About Us</name>
   <tag></tag>
   <elementGuidId>9b1658f9-740b-4d58-ace8-73094eb8c4d9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.easy-breadcrumb_segment.easy-breadcrumb_segment-1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-easy-breadcrumb-easy-breadcrumb']/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>346252f4-cace-4c94-9235-999b7d00aa75</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>easy-breadcrumb_segment easy-breadcrumb_segment-1</value>
      <webElementGuid>f9d436f7-563d-4f79-b771-76c03e59d0cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>About Us</value>
      <webElementGuid>be521fb2-4ae4-4173-b4fb-22840c719849</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-easy-breadcrumb-easy-breadcrumb&quot;)/div[@class=&quot;easy-breadcrumb&quot;]/span[@class=&quot;easy-breadcrumb_segment easy-breadcrumb_segment-1&quot;]</value>
      <webElementGuid>0b5b6936-276e-431e-80c6-33b8de613ce6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-easy-breadcrumb-easy-breadcrumb']/div/span[2]</value>
      <webElementGuid>8b8dcb4e-3cc9-42d6-9de7-4660a8660d0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>>'])[1]/following::span[1]</value>
      <webElementGuid>56c01187-8fac-4d88-8a8d-da4c873746b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::span[2]</value>
      <webElementGuid>b5a18a2d-2d99-4fb0-8d8b-e6ad54244ab6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>>'])[2]/preceding::span[1]</value>
      <webElementGuid>83b84085-dc1e-45bf-ab22-313beef2e3d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Historical Perspective'])[2]/preceding::span[2]</value>
      <webElementGuid>b9edecd5-ad74-426c-9bd7-12aac2430a3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/span[2]</value>
      <webElementGuid>af787228-9e5a-4a83-873b-873f4156684a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'About Us' or . = 'About Us')]</value>
      <webElementGuid>b540c1c1-9677-4f77-a372-8d04da940541</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
