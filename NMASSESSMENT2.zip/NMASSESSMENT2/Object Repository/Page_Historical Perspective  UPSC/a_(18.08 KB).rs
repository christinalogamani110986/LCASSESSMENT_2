<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_(18.08 KB)</name>
   <tag></tag>
   <elementGuidId>41c6b3ab-271c-4623-a346-eff68f7001a3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;PDF file that opens in a new window.&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'(18.08 KB)')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;(18.08 KB)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0f9f789b-52fa-4957-ac20-e55b96f0d33a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://upsc.gov.in/sites/default/files/History%20of%20the%20Commission%20final%20%281%29_0.pdf</value>
      <webElementGuid>9c4e0720-38b8-458a-8ee7-32dcaca98e0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_BLANK</value>
      <webElementGuid>739b17b4-5777-498d-8b14-5219a05ce551</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>PDF file that opens in a new window.</value>
      <webElementGuid>60c510f3-4cc0-4969-9a55-0b2f17078232</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>  (18.08 KB) </value>
      <webElementGuid>304ac8d6-8aeb-4159-9ef6-e481cfde9a50</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html not-front not-logged-in no-sidebars page-node page-node- page-node-33 node-type-about-us i18n-en&quot;]/section[@class=&quot;wrapper body-wrapper&quot;]/div[@class=&quot;container body-container inner-body fontSize&quot;]/div[@class=&quot;col-xs-12 col-sm-9 col-md-9 content-container fontSize&quot;]/div[@class=&quot;inner-right&quot;]/h1[@class=&quot;heading1&quot;]/a[1]</value>
      <webElementGuid>938a7e52-3081-4439-b460-1f7f9dc00079</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'(18.08 KB)')]</value>
      <webElementGuid>7b9c9469-2752-4cf3-a634-7d930888a7a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Virtual Tour of Museum'])[2]/following::a[2]</value>
      <webElementGuid>2337a922-ee61-491e-99e0-1223169b3a2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='हिन्दी'])[2]/preceding::a[1]</value>
      <webElementGuid>5e20aeca-c263-466f-a371-de3d6ca806ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Website Policies'])[1]/preceding::a[2]</value>
      <webElementGuid>5fa0c473-8782-42da-949b-063d0c7de7ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='(18.08 KB)']/parent::*</value>
      <webElementGuid>e3506eb6-6e7b-4736-a3a5-800c1f2ff8af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://upsc.gov.in/sites/default/files/History%20of%20the%20Commission%20final%20%281%29_0.pdf')]</value>
      <webElementGuid>1fae244e-d581-4d8a-93b4-a497c16ce0ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h1/a</value>
      <webElementGuid>24deaef7-7b08-4112-9a79-ada78d99a8b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://upsc.gov.in/sites/default/files/History%20of%20the%20Commission%20final%20%281%29_0.pdf' and @title = 'PDF file that opens in a new window.' and (text() = '  (18.08 KB) ' or . = '  (18.08 KB) ')]</value>
      <webElementGuid>f1cbce1d-a3a0-4652-8198-a5c409216fd4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
