<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_(315.93 KB)</name>
   <tag></tag>
   <elementGuidId>cb92c1dc-f6e6-409d-a1f2-109dafc576e6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;PDF file that opens in a new window.&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'(315.93 KB)')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;(315.93 KB)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5b7bd667-efb5-4411-a69b-ca5d1a33f643</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://upsc.gov.in/sites/default/files/RT-Intv-05-AstPRfLctrHomeoPhrmcy-engl-130624.pdf</value>
      <webElementGuid>d3e9f4eb-e0a2-4eee-8eb2-e538ac5f0c2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_BLANK</value>
      <webElementGuid>a7c92834-cf91-448b-a3d2-cf5717c3c36e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>PDF file that opens in a new window.</value>
      <webElementGuid>381d82ee-81ce-49d2-b016-71efba4a8315</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> (315.93 KB) </value>
      <webElementGuid>17a9a436-1a62-45e5-8f2a-f1db173fa66c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html not-front not-logged-in no-sidebars page-recruitment page-recruitment-recruitment-test page-recruitment-recruitment-test-interview-details i18n-en&quot;]/section[@class=&quot;wrapper body-wrapper&quot;]/div[@class=&quot;container body-container inner-body fontSize&quot;]/div[@class=&quot;col-xs-12 col-sm-9 col-md-9 content-container fontSize&quot;]/div[@class=&quot;inner-right&quot;]/div[@class=&quot;view view-recruitment view-id-recruitment view-display-id-page_12 view-dom-id-c653207e8086a51bd5d35e1ce4acde5d&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;scroll-table1&quot;]/table[@class=&quot;views-table cols-5 table table-0 table-0 table-0 table-0&quot;]/tbody[1]/tr[@class=&quot;odd views-row-first&quot;]/td[@class=&quot;views-field views-field-php&quot;]/ul[@class=&quot;arrows&quot;]/li[1]/a[1]</value>
      <webElementGuid>ee3f3ac0-806e-418f-8641-49bea24040e3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'(315.93 KB)')]</value>
      <webElementGuid>8e0178ee-5ead-443c-bed7-9927856ede5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Date of Upload'])[1]/following::a[1]</value>
      <webElementGuid>1d5ca104-8c48-4171-b274-f028741566e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Documents'])[1]/following::a[1]</value>
      <webElementGuid>ef2b5dac-0765-4c75-945c-782833970c9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(197.05 KB)'])[1]/preceding::a[1]</value>
      <webElementGuid>aeb8ad7b-c0bd-40a5-8fa0-fd56752761b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(686.15 KB)'])[1]/preceding::a[2]</value>
      <webElementGuid>4103cc8c-458d-4f06-a33a-bd7c78937c93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='(315.93 KB)']/parent::*</value>
      <webElementGuid>9b49e919-f953-4055-baab-cc84548b3933</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://upsc.gov.in/sites/default/files/RT-Intv-05-AstPRfLctrHomeoPhrmcy-engl-130624.pdf')]</value>
      <webElementGuid>056e622e-dcfd-4808-a646-40646d663241</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[4]/ul/li/a</value>
      <webElementGuid>66c0d720-0c37-4237-94a2-53f5e0b49771</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://upsc.gov.in/sites/default/files/RT-Intv-05-AstPRfLctrHomeoPhrmcy-engl-130624.pdf' and @title = 'PDF file that opens in a new window.' and (text() = ' (315.93 KB) ' or . = ' (315.93 KB) ')]</value>
      <webElementGuid>c68be025-457d-465e-9958-d447883674fb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
