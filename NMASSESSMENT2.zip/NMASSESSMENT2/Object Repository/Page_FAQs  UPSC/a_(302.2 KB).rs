<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_(302.2 KB)</name>
   <tag></tag>
   <elementGuidId>e3ea4b2d-9064-4ba7-8679-e50478594e11</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;PDF file that opens in a new window.&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='collapse0']/div/div/span/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;(302.2 KB)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2c5f141f-fed6-4274-8803-46b8289225d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://upsc.gov.in/sites/default/files/FAQ_S-II_Eng_14032023_0.pdf</value>
      <webElementGuid>df8ce0ef-9c27-4049-bf4c-95b11a3d474d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_BLANK</value>
      <webElementGuid>5aa75460-413c-4d16-a486-9d78085d9114</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>PDF file that opens in a new window.</value>
      <webElementGuid>e0d2e279-c56e-4c98-b813-f932ae29c553</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> (302.2 KB) </value>
      <webElementGuid>28657a20-f7ec-4ac8-8446-c9c177d87a0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;collapse0&quot;)/div[@class=&quot;panel-body&quot;]/div[@class=&quot;views-field views-field-php&quot;]/span[@class=&quot;field-content&quot;]/ul[@class=&quot;arrows&quot;]/li[1]/a[1]</value>
      <webElementGuid>2bc0ad79-17a5-479c-9f64-d45c48cb3d8c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='collapse0']/div/div/span/ul/li/a</value>
      <webElementGuid>f43fa4f0-599d-466c-81f9-9fe98a1fb9d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'(302.2 KB)')]</value>
      <webElementGuid>34aa0149-3d3d-46dc-8bc7-30f2c5c316a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Policy and Coordination Branch'])[1]/following::a[1]</value>
      <webElementGuid>92d13b04-3a0c-42f4-8a2d-5518c3b50511</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Disciplinary and Appeal Cases Branch'])[1]/preceding::a[1]</value>
      <webElementGuid>e0778ecf-29de-43cb-8a79-00975eedb12d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='(302.2 KB)']/parent::*</value>
      <webElementGuid>95968567-ee89-478a-b641-b2607bdb085f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://upsc.gov.in/sites/default/files/FAQ_S-II_Eng_14032023_0.pdf')]</value>
      <webElementGuid>cfac0c52-7f36-475c-8646-dd3f6a638a04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/ul/li/a</value>
      <webElementGuid>f1a99508-fdc3-45eb-9413-e7e020c5efde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://upsc.gov.in/sites/default/files/FAQ_S-II_Eng_14032023_0.pdf' and @title = 'PDF file that opens in a new window.' and (text() = ' (302.2 KB) ' or . = ' (302.2 KB) ')]</value>
      <webElementGuid>66ac7b66-9259-4909-afcd-1a34ad9f2427</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
