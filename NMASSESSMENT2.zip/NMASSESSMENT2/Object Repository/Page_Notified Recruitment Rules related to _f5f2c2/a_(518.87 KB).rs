<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_(518.87 KB)</name>
   <tag></tag>
   <elementGuidId>e0923bb5-489f-424e-89ae-3e539b9948bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;PDF file that opens in a new window.&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'(518.87 KB)')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;(518.87 KB)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2ca730ce-1530-4547-9cc1-5dbd775fc8aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://upsc.gov.in/sites/default/files/NotifRR-SuprvsrConfidentl-en-hn-250823.pdf</value>
      <webElementGuid>ecb29279-4666-4f5a-ae73-3bd3e4a1474b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_BLANK</value>
      <webElementGuid>60a7e28f-c8e7-453a-baf3-af35e6333d44</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>PDF file that opens in a new window.</value>
      <webElementGuid>310a514f-5685-48eb-80e6-42ddaa8db976</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> (518.87 KB) </value>
      <webElementGuid>4d0772d0-ba44-45c9-ac92-57bb30ef724d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html not-front not-logged-in no-sidebars page-about-us page-about-us-divisions page-about-us-divisions-administration page-about-us-divisions-administration-recruitment-rules page-about-us-divisions-administration-recruitment-rules-notified-recruitment-rules i18n-en&quot;]/section[@class=&quot;wrapper body-wrapper&quot;]/div[@class=&quot;container body-container inner-body fontSize&quot;]/div[@class=&quot;col-xs-12 col-sm-9 col-md-9 content-container fontSize&quot;]/div[@class=&quot;inner-right&quot;]/div[@class=&quot;view view-notified-recruitment-rules view-id-notified_recruitment_rules view-display-id-page_1 view-dom-id-1a9ee14964a57a179e850aeb394a239c&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;item-list&quot;]/ul[1]/li[@class=&quot;views-row views-row-1 views-row-odd views-row-first&quot;]/div[@class=&quot;views-field views-field-php&quot;]/span[@class=&quot;field-content&quot;]/ul[@class=&quot;arrows&quot;]/li[1]/a[1]</value>
      <webElementGuid>11fac1d9-adbf-4d7a-824f-ef9a8d6241bd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'(518.87 KB)')]</value>
      <webElementGuid>67e49a0f-658d-4a4f-aae6-df2888d1f256</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notified Recruitment Rules related to UPSC Posts'])[3]/following::a[1]</value>
      <webElementGuid>5e2e8f74-c0f3-4a3a-8664-bd8386f8e837</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(1.15 MB)'])[1]/preceding::a[1]</value>
      <webElementGuid>98e2c6b4-9dd6-4163-a543-1837c6af846c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='(518.87 KB)']/parent::*</value>
      <webElementGuid>52487889-a6d1-40f5-b55b-4e3a47ce3241</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://upsc.gov.in/sites/default/files/NotifRR-SuprvsrConfidentl-en-hn-250823.pdf')]</value>
      <webElementGuid>c560f2d1-170a-4db0-a285-86c44ed91bfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/ul/li/a</value>
      <webElementGuid>208cb65b-0988-45b9-849e-3cb022798dd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://upsc.gov.in/sites/default/files/NotifRR-SuprvsrConfidentl-en-hn-250823.pdf' and @title = 'PDF file that opens in a new window.' and (text() = ' (518.87 KB) ' or . = ' (518.87 KB) ')]</value>
      <webElementGuid>c2152f7f-9b2f-45b2-874c-250bfaff44c0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
