<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_One Time Registration (OTR) for Examinations</name>
   <tag></tag>
   <elementGuidId>f4aed981-4ddb-4338-a26d-4ee3a297c108</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.menu.nav > li.last.leaf > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[10]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;One Time Registration (OTR) for Examinations&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>70fbb593-2648-44ff-8d01-5dcc37d8b2ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://upsconline.nic.in/upsc/OTRP/index.php</value>
      <webElementGuid>b4fac42a-4e52-412f-a552-dc495ebc1777</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>One Time Registration (OTR) for Examinations</value>
      <webElementGuid>27ab3015-6650-4e97-864e-5b7cb77eaf7a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;last leaf&quot;]/a[1]</value>
      <webElementGuid>8e3e3469-5238-4d17-ba25-89f2e93cd38d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[10]/a</value>
      <webElementGuid>588ec551-2c12-40bb-b918-1b9865653d66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'One Time Registration (OTR) for Examinations')]</value>
      <webElementGuid>e7efa550-d059-4bec-b43f-e5225e1b38bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Helpline - SC/ST/OBC/EWS/PwBD (1800-118-711)'])[1]/following::a[1]</value>
      <webElementGuid>5dc9a5ec-eb8f-486e-a847-1de48713da2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RTI'])[1]/following::a[2]</value>
      <webElementGuid>f9f07264-c0f9-4ec5-9f98-eb059ae2afb3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/preceding::a[1]</value>
      <webElementGuid>fdefd7f2-121e-4e3d-a8c3-d644c1e822ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>>'])[1]/preceding::a[2]</value>
      <webElementGuid>707224ed-0d53-4733-aa12-2a5c07e80ab7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='One Time Registration (OTR) for Examinations']/parent::*</value>
      <webElementGuid>7670adae-4504-4577-9784-de3bde04e110</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://upsconline.nic.in/upsc/OTRP/index.php')]</value>
      <webElementGuid>d0aa783c-795a-4138-adc3-c444a9b393f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/a</value>
      <webElementGuid>451c9c66-ede7-4c60-88d6-3b79f9c5cea1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://upsconline.nic.in/upsc/OTRP/index.php' and (text() = 'One Time Registration (OTR) for Examinations' or . = 'One Time Registration (OTR) for Examinations')]</value>
      <webElementGuid>796c37a7-4d38-4c48-b5b6-528efeb310c6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
