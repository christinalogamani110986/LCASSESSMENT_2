<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Demo Files</name>
   <tag></tag>
   <elementGuidId>1277c3c7-56bf-4b64-98ac-eb63992c8f54</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.last.leaf.menu-mlid-2745 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[13]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Demo Files&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e4d76d2f-cbbf-4d1f-8787-e36d3857c6d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/examinations/demo-files-computer-based-combined-medical-service-examination</value>
      <webElementGuid>e3893b59-4902-42ff-8e0c-25e4cca3854f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Demo Files</value>
      <webElementGuid>d27e537b-d082-404c-b3d4-76f801cd19ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;last leaf menu-mlid-2745&quot;]/a[1]</value>
      <webElementGuid>f7e0909f-a1b0-473b-af22-d3f7c1454102</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[13]/a</value>
      <webElementGuid>a8c751e8-5583-45b9-a8fa-f055fc92abc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Demo Files')])[2]</value>
      <webElementGuid>ad377ad2-eff1-44fd-8110-da74057f0447</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Representation on Question Papers'])[4]/following::a[1]</value>
      <webElementGuid>5970bcdb-14e7-4920-93d8-aa06f43bb25d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Revised Syllabus and Scheme'])[2]/following::a[2]</value>
      <webElementGuid>bd9bea82-bcfa-410f-833f-d0b7a473bb08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(490.26 KB)'])[1]/preceding::a[2]</value>
      <webElementGuid>0855c4ba-91d7-446e-8fe3-4b4dbd0b5338</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/examinations/demo-files-computer-based-combined-medical-service-examination')])[2]</value>
      <webElementGuid>ad2bf27f-34dd-4e3b-9a42-d567e1bbad9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[13]/a</value>
      <webElementGuid>d80b6a23-6eb4-4bc8-9ad0-a98dfc9c634f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/examinations/demo-files-computer-based-combined-medical-service-examination' and (text() = 'Demo Files' or . = 'Demo Files')]</value>
      <webElementGuid>723d5ca6-ea10-41ad-a2d3-dd9cdedaf3d2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
