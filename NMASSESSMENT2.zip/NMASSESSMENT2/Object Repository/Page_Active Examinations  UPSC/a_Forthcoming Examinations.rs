<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Forthcoming Examinations</name>
   <tag></tag>
   <elementGuidId>e2f68e51-85da-4546-b966-c69188167252</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[3]/ul/li[3]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#main-menu >> internal:role=link[name=&quot;Forthcoming Examinations&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d1086089-2314-46dd-85dc-179352622ff3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/examinations/forthcoming-exams</value>
      <webElementGuid>869d8834-06ec-4536-9ce8-1358a19e8544</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Forthcoming Examinations</value>
      <webElementGuid>72800b21-6621-46e7-a950-dd3ac1389480</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;expanded active-trail dropdown&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[@class=&quot;leaf fontSize&quot;]/a[1]</value>
      <webElementGuid>a7497ffa-7f8a-493c-b0e7-a197734c4086</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[3]/ul/li[3]/a</value>
      <webElementGuid>b61ee3ca-cec6-47a3-a0e8-e7facbc6d6e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Forthcoming Examinations')]</value>
      <webElementGuid>481a3018-93db-4a2e-b275-b3ef87d2742e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Active Examinations'])[1]/following::a[1]</value>
      <webElementGuid>9ce4da52-1fa4-4f03-b348-1c4faa0c4305</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Calendar'])[1]/following::a[2]</value>
      <webElementGuid>76d55e68-863e-47a0-8eed-ac501ac76371</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Question Papers'])[1]/preceding::a[1]</value>
      <webElementGuid>976c939b-c63a-4676-982b-b9b5b658f7d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cut-off Marks'])[1]/preceding::a[2]</value>
      <webElementGuid>55873d8b-4f29-491b-a6c5-d4e2f5e9946b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Forthcoming Examinations']/parent::*</value>
      <webElementGuid>e52416e7-c845-403b-8759-3d2f01d480bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/examinations/forthcoming-exams')]</value>
      <webElementGuid>c32ef092-56a9-4d82-8336-98d78c787667</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/ul/li[3]/a</value>
      <webElementGuid>e03e4b49-70f0-4139-94b1-891059b5116d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/examinations/forthcoming-exams' and (text() = 'Forthcoming Examinations' or . = 'Forthcoming Examinations')]</value>
      <webElementGuid>09a9a7ac-eccf-4535-ba77-24d532e9c1ed</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
