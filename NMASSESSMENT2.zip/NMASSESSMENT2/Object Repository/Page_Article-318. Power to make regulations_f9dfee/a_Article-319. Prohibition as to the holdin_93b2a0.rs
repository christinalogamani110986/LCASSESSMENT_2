<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-319. Prohibition as to the holdin_93b2a0</name>
   <tag></tag>
   <elementGuidId>37ba5981-a0f4-46b6-8f5a-4d56a8de6ae3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1470 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[5]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-319. Prohibition as to the holding of offices by members of Commission on ceasing to be such members.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>de1ad0f1-8008-4141-8798-138054fda1c0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-319-prohibition-holding-offices-members-commission-ceasing-be-such-members</value>
      <webElementGuid>3e31bbec-d6dd-4475-8d82-3754ad7c9157</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-319. Prohibition as to the holding of offices by members of Commission on ceasing to be such members.</value>
      <webElementGuid>7762a8a3-f698-4f1c-b2ee-93e615a9e414</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1470&quot;]/a[1]</value>
      <webElementGuid>d54f74f5-d185-4ab4-b625-32f7f36465ea</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[5]/a</value>
      <webElementGuid>8d9ee922-75fd-40e6-aa1a-9d977105c016</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-319. Prohibition as to the holding of offices by members of Commission on ceasing to be such members.')]</value>
      <webElementGuid>4f63ec21-62c6-4877-ba0c-f8c06ee8ceb6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-317. Removal and suspension of a member of a Public Service Commission.'])[1]/following::a[2]</value>
      <webElementGuid>cbfe2a25-21a2-4bd1-937c-5ef2bb76ff0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-316. Appointment and term of office of members.'])[1]/following::a[3]</value>
      <webElementGuid>c521671b-bebb-4711-9c40-e9189558cff1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-320. Functions of Public Service Commissions.'])[1]/preceding::a[1]</value>
      <webElementGuid>135ba802-44d0-4f83-a547-c5ff0f783707</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.'])[1]/preceding::a[2]</value>
      <webElementGuid>e562a595-7d5b-45fe-a444-809939b6b238</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-319. Prohibition as to the holding of offices by members of Commission on ceasing to be such members.']/parent::*</value>
      <webElementGuid>f582a330-5f4f-4e4c-9753-61fddf4ad9c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-319-prohibition-holding-offices-members-commission-ceasing-be-such-members')]</value>
      <webElementGuid>75ac0947-46f7-4cb7-8da0-890fcc175206</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[5]/a</value>
      <webElementGuid>fe2978f7-fe64-4155-94cc-e80a2f4207a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-319-prohibition-holding-offices-members-commission-ceasing-be-such-members' and (text() = 'Article-319. Prohibition as to the holding of offices by members of Commission on ceasing to be such members.' or . = 'Article-319. Prohibition as to the holding of offices by members of Commission on ceasing to be such members.')]</value>
      <webElementGuid>2ac57676-7da8-400e-90e6-d0c7162d5da0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
