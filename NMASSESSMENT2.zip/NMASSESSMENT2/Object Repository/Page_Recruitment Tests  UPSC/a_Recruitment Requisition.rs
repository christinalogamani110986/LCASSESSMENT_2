<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Recruitment Requisition</name>
   <tag></tag>
   <elementGuidId>3dba1543-bce0-4c54-a340-df827784e0a4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1384 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[7]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Recruitment Requisition&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c40f604b-5abf-452b-aff7-9afb541e7382</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/recruitment/recruitment-requisition</value>
      <webElementGuid>dcf86edf-27dd-4c59-9312-32de8fed7027</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Recruitment Requisition</value>
      <webElementGuid>e41e1134-cfd4-4fbf-9e80-1a8f44c759ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1384&quot;]/a[1]</value>
      <webElementGuid>e66e4b5b-f23d-4796-8a06-0992f79f83b3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[7]/a</value>
      <webElementGuid>1d692372-461b-4137-b67a-b76d6fbcc596</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Recruitment Requisition')])[2]</value>
      <webElementGuid>553f3b2d-c2ae-41b2-b782-10a9db6b8e7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Tests'])[3]/following::a[1]</value>
      <webElementGuid>d26a35b4-16ef-4ad6-9be3-f55f2a84c8e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forms for Certificates'])[2]/following::a[2]</value>
      <webElementGuid>c7bf3731-cf8d-4195-a199-45e1ea138132</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment cases kept on hold on account of Pending Litigations'])[2]/preceding::a[1]</value>
      <webElementGuid>aa821942-910d-4ea4-9330-17bce8e2a371</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Representation on Question Papers'])[3]/preceding::a[2]</value>
      <webElementGuid>b33bce98-13c0-430f-989b-6a89411fdfdf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/recruitment/recruitment-requisition')])[2]</value>
      <webElementGuid>de97f7ce-5cc5-4296-97d9-0b8e16d2c34c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[7]/a</value>
      <webElementGuid>b8d5790f-4348-464f-a1c2-353f5964e611</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/recruitment/recruitment-requisition' and (text() = 'Recruitment Requisition' or . = 'Recruitment Requisition')]</value>
      <webElementGuid>fc95e16b-c43b-4b86-bd24-32331831a120</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
