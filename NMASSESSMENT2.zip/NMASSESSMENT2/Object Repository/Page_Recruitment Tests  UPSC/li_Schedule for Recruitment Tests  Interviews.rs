<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Schedule for Recruitment Tests  Interviews</name>
   <tag></tag>
   <elementGuidId>3cbe7ddc-660f-4384-8088-d3394661a017</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.arrows > li</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-views-basic-page-block']/div/div/div/div[4]/div/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=&quot;Schedule for Recruitment Tests &amp; Interviews&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>75a45a16-fe99-4634-8c06-cf12020f99f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Schedule for Recruitment Tests &amp; Interviews</value>
      <webElementGuid>d52590f2-bea8-4f18-95e7-a0a8a46e5f0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-views-basic-page-block&quot;)/div[@class=&quot;view view-basic-page view-id-basic_page view-display-id-block view-dom-id-775803d540cc0d7096d81c49622b06b4&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;views-row views-row-1 views-row-odd views-row-first views-row-last&quot;]/div[@class=&quot;views-field views-field-field-link&quot;]/div[@class=&quot;field-content&quot;]/ul[@class=&quot;arrows&quot;]/li[1]</value>
      <webElementGuid>1cd8bff4-2567-4fdf-95e3-c3786094b2ff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-views-basic-page-block']/div/div/div/div[4]/div/ul/li</value>
      <webElementGuid>e00d54bf-47af-4ae4-8cc9-a8884333f752</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Tests'])[4]/following::li[1]</value>
      <webElementGuid>ee62f389-19df-4ad1-b161-0e7c6a37822b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Representation on Question Papers'])[3]/following::li[1]</value>
      <webElementGuid>bfa1be85-f1de-4742-9c9d-af0c65b90adf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notice'])[1]/preceding::li[1]</value>
      <webElementGuid>e1253fb6-2782-4704-9dbb-7c96b0deb9a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/ul/li</value>
      <webElementGuid>2c51505f-f7f4-4c2b-b69d-6857b3f5aa04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Schedule for Recruitment Tests &amp; Interviews' or . = 'Schedule for Recruitment Tests &amp; Interviews')]</value>
      <webElementGuid>dbb5c296-85dd-4cc6-ba50-048209f575a9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
