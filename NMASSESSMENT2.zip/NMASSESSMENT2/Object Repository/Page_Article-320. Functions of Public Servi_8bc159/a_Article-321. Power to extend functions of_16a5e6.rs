<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-321. Power to extend functions of_16a5e6</name>
   <tag></tag>
   <elementGuidId>88d6a5f9-0f0e-43e0-8bfb-5bb715f416e0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1472 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[7]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-321. Power to extend functions of Public Service Commissions.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>100ef325-6cc4-4318-805b-58cda9ecd842</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-321-power-extend-functions-public-service-commissions-0</value>
      <webElementGuid>a68af3e5-a0e2-4a78-bb1b-14997b54af91</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-321. Power to extend functions of Public Service Commissions.</value>
      <webElementGuid>c86d4848-91c3-46bc-b86b-ca438af1d175</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1472&quot;]/a[1]</value>
      <webElementGuid>90e9782c-8949-4a42-adc9-dd753eb9cff5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[7]/a</value>
      <webElementGuid>629d1507-2171-44f6-8a12-7e0fe461a85d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-321. Power to extend functions of Public Service Commissions.')]</value>
      <webElementGuid>1278212a-9d85-46eb-9202-a4913e81de55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-320. Functions of Public Service Commissions.'])[2]/following::a[1]</value>
      <webElementGuid>108a2897-0016-41ff-af83-7c7c51deb319</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-317. Removal and suspension of a member of a Public Service Commission.'])[1]/following::a[4]</value>
      <webElementGuid>c18ed23b-f055-4413-92d2-00f8ccbb31ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-322. Expenses of Public Service Commissions.'])[1]/preceding::a[1]</value>
      <webElementGuid>c57cdc17-6930-4155-8a1c-96efe59981fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-323. Reports of Public Service Commissions.'])[1]/preceding::a[2]</value>
      <webElementGuid>2a2c6d3f-a037-429d-9fd2-ba67277ec790</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.']/parent::*</value>
      <webElementGuid>5973ad91-0b3d-439b-8a71-74e2c7b00e05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-321-power-extend-functions-public-service-commissions-0')]</value>
      <webElementGuid>db9d9ad5-15f2-42cf-ab3f-1b5250afef26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[7]/a</value>
      <webElementGuid>1610ca79-3c19-43df-be32-7f89302c113c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-321-power-extend-functions-public-service-commissions-0' and (text() = 'Article-321. Power to extend functions of Public Service Commissions.' or . = 'Article-321. Power to extend functions of Public Service Commissions.')]</value>
      <webElementGuid>c11b6102-cef5-41a5-ac2a-ac0d91d3c806</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
