<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-320. Functions of Public Service _b14684</name>
   <tag></tag>
   <elementGuidId>57f56cbe-3f1f-4f88-a830-41d516f94c3f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1471 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[6]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-320. Functions of Public Service Commissions.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>62e89596-c793-4b1e-9df4-f86a1c9195a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-320-functions-public-service-commissions</value>
      <webElementGuid>a4544d10-be9e-4843-80b9-457477ec4590</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-320. Functions of Public Service Commissions.</value>
      <webElementGuid>53ee76e4-ce02-47ba-8a9c-a7755ae3c0e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1471&quot;]/a[1]</value>
      <webElementGuid>4dc530ef-fe1f-4c05-a762-c84f15b9bdb6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[6]/a</value>
      <webElementGuid>3d6761ad-597a-439e-878c-cfab45229509</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-320. Functions of Public Service Commissions.')]</value>
      <webElementGuid>0b5ba0a2-f329-406b-9075-14c574b6fcd7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-317. Removal and suspension of a member of a Public Service Commission.'])[1]/following::a[3]</value>
      <webElementGuid>faecbd3d-643d-4f33-a69d-0ba87dde8c73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-316. Appointment and term of office of members.'])[1]/following::a[4]</value>
      <webElementGuid>159d2b87-6176-47e4-b638-79dafbcd2016</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.'])[1]/preceding::a[1]</value>
      <webElementGuid>8422844c-6f4e-4e56-ac1f-d518c624b052</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-322. Expenses of Public Service Commissions.'])[1]/preceding::a[2]</value>
      <webElementGuid>c493dde0-c6c4-4652-af5c-631a25046c49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-320. Functions of Public Service Commissions.']/parent::*</value>
      <webElementGuid>232b1c7e-6d6f-4d8b-9135-16aad93d37ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-320-functions-public-service-commissions')]</value>
      <webElementGuid>888f0149-e0b6-4529-8eff-04c7415af7de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[6]/a</value>
      <webElementGuid>c3cc0a50-3b9a-4312-8f49-c44688762c1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-320-functions-public-service-commissions' and (text() = 'Article-320. Functions of Public Service Commissions.' or . = 'Article-320. Functions of Public Service Commissions.')]</value>
      <webElementGuid>862d6532-6903-4e40-b87b-2a64c6dfdc05</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
