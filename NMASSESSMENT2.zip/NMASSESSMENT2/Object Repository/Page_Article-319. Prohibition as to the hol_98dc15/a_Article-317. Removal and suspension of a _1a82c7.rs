<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-317. Removal and suspension of a _1a82c7</name>
   <tag></tag>
   <elementGuidId>fc70be74-d4ad-4e30-be31-f9e664be037a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1468 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[3]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-317. Removal and suspension of a member of a Public Service Commission.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>06cbd15b-2d40-4a17-a8f5-b9c582a21a31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-317-removal-and-suspension-member-public-service-commission</value>
      <webElementGuid>40e9fed6-bfab-4b27-b11a-685b77595c1c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-317. Removal and suspension of a member of a Public Service Commission.</value>
      <webElementGuid>860dc4f6-23e9-4eaf-a4f5-3e1ebc198dcb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1468&quot;]/a[1]</value>
      <webElementGuid>24878132-5d1a-498d-b1db-a28d017d5a56</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[3]/a</value>
      <webElementGuid>4927e586-b253-4f82-8217-128a34e3081f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-317. Removal and suspension of a member of a Public Service Commission.')]</value>
      <webElementGuid>51e97bf7-af81-4f3d-bdb4-bb1ebb0a84c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-316. Appointment and term of office of members.'])[1]/following::a[1]</value>
      <webElementGuid>a23c7692-73e6-4482-af47-0ea0e2c450f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-315. Public Service Commissions for the Union and for the States.'])[1]/following::a[2]</value>
      <webElementGuid>385b475a-8094-4d6c-89fa-641416a32b79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-320. Functions of Public Service Commissions.'])[1]/preceding::a[3]</value>
      <webElementGuid>44d80764-a355-4cf8-ae08-322ccb346282</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.'])[1]/preceding::a[4]</value>
      <webElementGuid>0435ff12-63d2-4152-92b8-12adb0e892ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-317. Removal and suspension of a member of a Public Service Commission.']/parent::*</value>
      <webElementGuid>854f618b-620f-45ba-b7b7-33e67fb7e08d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-317-removal-and-suspension-member-public-service-commission')]</value>
      <webElementGuid>e9956143-09b3-49bd-a7e9-630ae0b0e536</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[3]/a</value>
      <webElementGuid>6b6e7f0b-afc6-4d1d-ba79-0cdae442cd3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-317-removal-and-suspension-member-public-service-commission' and (text() = 'Article-317. Removal and suspension of a member of a Public Service Commission.' or . = 'Article-317. Removal and suspension of a member of a Public Service Commission.')]</value>
      <webElementGuid>df22d74a-4189-40d7-825a-46a8de334b82</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
