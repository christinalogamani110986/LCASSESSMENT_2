<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-323. Reports of Public Service Co_b2187b</name>
   <tag></tag>
   <elementGuidId>fbb9309b-0a9e-48b0-ab6c-6a8e754afca6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.last.leaf.menu-mlid-1474 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[9]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-323. Reports of Public Service Commissions.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5eff8201-a02f-4317-a704-c883ad168ad4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-323-reports-public-service-commissions</value>
      <webElementGuid>3db2d833-8ffd-4a7c-a3b6-dc89d2af1167</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-323. Reports of Public Service Commissions.</value>
      <webElementGuid>7fa83848-2951-4d94-bc33-84d96eaec49f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;last leaf menu-mlid-1474&quot;]/a[1]</value>
      <webElementGuid>bf9b1713-ecff-4926-b8be-a63551c8ee19</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[9]/a</value>
      <webElementGuid>1160b511-515a-4daf-a20b-660b820d927d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-323. Reports of Public Service Commissions.')]</value>
      <webElementGuid>7c9d0294-1b6f-4e7e-b824-a3f1fb9d3952</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-322. Expenses of Public Service Commissions.'])[2]/following::a[1]</value>
      <webElementGuid>26d973f1-37a0-4fb8-bd37-822300d35077</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.'])[1]/following::a[2]</value>
      <webElementGuid>70ac10e4-c433-4e57-b8c5-7803a7d2bd74</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-322. Expenses of Public Service Commissions.'])[3]/preceding::a[2]</value>
      <webElementGuid>6017004e-ee67-41f6-99f3-3fa6e79e398e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='हिन्दी'])[2]/preceding::a[2]</value>
      <webElementGuid>e4c58c3a-d98a-47b3-bba0-bb819df5f5e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-323. Reports of Public Service Commissions.']/parent::*</value>
      <webElementGuid>deda1e19-ec2d-4967-bb32-8780b1021fab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-323-reports-public-service-commissions')]</value>
      <webElementGuid>8dc503dc-68ee-4a8f-9d27-03a588634448</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[9]/a</value>
      <webElementGuid>3b3f341a-0a97-4100-8226-0d1f224fb897</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-323-reports-public-service-commissions' and (text() = 'Article-323. Reports of Public Service Commissions.' or . = 'Article-323. Reports of Public Service Commissions.')]</value>
      <webElementGuid>45150611-23d8-4db5-81f4-f5344d9a8025</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
