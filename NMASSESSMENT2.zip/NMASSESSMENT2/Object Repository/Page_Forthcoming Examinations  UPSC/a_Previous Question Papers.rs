<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Previous Question Papers</name>
   <tag></tag>
   <elementGuidId>62131806-78f2-4dea-94c0-7cfd1d8484da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[3]/ul/li[4]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#main-menu >> internal:role=link[name=&quot;Previous Question Papers&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>efd92f7f-ff26-42d9-abdd-c1f772a189ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/examinations/previous-question-papers</value>
      <webElementGuid>5a786d33-0185-49aa-95b4-fb30bdad4ab0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Previous Question Papers</value>
      <webElementGuid>7facf6dd-b8cb-4131-b384-dbffbaf2f2c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;expanded active-trail dropdown&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[@class=&quot;leaf fontSize&quot;]/a[1]</value>
      <webElementGuid>66a284c9-4da5-49ee-b302-10e2b701ea4c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[3]/ul/li[4]/a</value>
      <webElementGuid>46181058-8234-439e-8534-1c5b81d1d889</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Previous Question Papers')]</value>
      <webElementGuid>7c201937-dbaf-4ea4-bfb1-73ed1beafe3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forthcoming Examinations'])[1]/following::a[1]</value>
      <webElementGuid>3af9de17-bda2-424e-b3b5-f849fdb106c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Active Examinations'])[1]/following::a[2]</value>
      <webElementGuid>04850896-ea1d-470f-896b-0413b1bacdf6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cut-off Marks'])[1]/preceding::a[1]</value>
      <webElementGuid>0ea107a2-a8be-4f16-aafa-0a552e4f349e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Answer Keys'])[1]/preceding::a[2]</value>
      <webElementGuid>76725ea6-5cbf-4185-bede-5d7bb5cb3924</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Previous Question Papers']/parent::*</value>
      <webElementGuid>0ba5856f-b754-4592-8177-74dd28f66479</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/examinations/previous-question-papers')]</value>
      <webElementGuid>766831b6-418c-4cac-9cd7-ad321add3b23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/ul/li[4]/a</value>
      <webElementGuid>4ae4ae8c-ce1a-4853-841e-bdc244eec418</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/examinations/previous-question-papers' and (text() = 'Previous Question Papers' or . = 'Previous Question Papers')]</value>
      <webElementGuid>2eab8fee-cf4f-4464-b82e-6c21b7c9f252</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
