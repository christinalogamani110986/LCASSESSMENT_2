<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Demo Files</name>
   <tag></tag>
   <elementGuidId>9827cf5f-6999-4408-96bf-3e86a5846cf4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.last.leaf.menu-mlid-2745 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[13]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Demo Files&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f9d0c843-6c7f-427f-bb19-ca9b9b493891</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/examinations/demo-files-computer-based-combined-medical-service-examination</value>
      <webElementGuid>0653ccbb-e2aa-40ff-b631-2f77181703ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Demo Files</value>
      <webElementGuid>ef5979f5-75ae-434f-a69b-8f4377a51d46</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;last leaf menu-mlid-2745&quot;]/a[1]</value>
      <webElementGuid>3fa773d0-e2ee-4ca4-bd8e-c49e65c11d1f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[13]/a</value>
      <webElementGuid>2391b992-b0c7-414b-aab4-0d63bcbd324d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Demo Files')])[2]</value>
      <webElementGuid>f08f03b1-5081-47bb-b04b-39ea13266c37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Representation on Question Papers'])[3]/following::a[1]</value>
      <webElementGuid>bb6bc2c7-cd2f-47ca-b7ee-dd6dbc3b9b26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Revised Syllabus and Scheme'])[2]/following::a[2]</value>
      <webElementGuid>ef19a471-9944-4834-8195-701d6a4a89d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forthcoming Examinations'])[4]/preceding::a[2]</value>
      <webElementGuid>5b547cde-43e4-4ef1-8e1d-1f6fcbc3e0b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SO - Steno (GD-B-GD-I) LDCE'])[1]/preceding::a[2]</value>
      <webElementGuid>80044fa0-753e-453c-8241-2311beff0537</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/examinations/demo-files-computer-based-combined-medical-service-examination')])[2]</value>
      <webElementGuid>c2cd7097-e067-4b07-bc67-55c0c2a564cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[13]/a</value>
      <webElementGuid>c2d4061f-3d24-452d-8196-ad9dde199dcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/examinations/demo-files-computer-based-combined-medical-service-examination' and (text() = 'Demo Files' or . = 'Demo Files')]</value>
      <webElementGuid>3d976a30-088e-4038-962c-093b6033cced</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
