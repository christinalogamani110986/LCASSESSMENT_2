<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Specimen Question Cum Answer Booklet (QCAB)</name>
   <tag></tag>
   <elementGuidId>596755ff-6626-4b91-a098-e1f325998cb9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-2733 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[9]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Specimen Question Cum Answer Booklet (QCAB)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a239acce-44f0-4622-a48e-7c48da95f648</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/examination/model-question-and-answer-booklets</value>
      <webElementGuid>c4bd8042-461d-4097-8a89-51d82a8cca3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Specimen Question Cum Answer Booklet (QCAB)</value>
      <webElementGuid>5d998042-edad-4f64-a6c6-27557552011b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-2733&quot;]/a[1]</value>
      <webElementGuid>7a3a9eaa-c5f3-4917-b193-85970423ed25</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[9]/a</value>
      <webElementGuid>5896098a-16a9-4631-800f-9f44fffec609</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Specimen Question Cum Answer Booklet (QCAB)')])[2]</value>
      <webElementGuid>9165fc0f-a30b-4295-a3a8-da039c63e40f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Public Disclosure of marks &amp; other details of non-recommended willing candidates'])[3]/following::a[1]</value>
      <webElementGuid>7df5e2aa-2179-4bfc-b860-a034c9e014a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Marks Information'])[2]/following::a[2]</value>
      <webElementGuid>a730b7d0-d552-4d25-808f-f1f814bed343</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Common mistakes committed by the candidates in Conventional Papers'])[2]/preceding::a[1]</value>
      <webElementGuid>a0f0a63b-cccf-4350-a9e7-f87c281bfb1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Revised Syllabus and Scheme'])[2]/preceding::a[2]</value>
      <webElementGuid>0758a72a-2b09-47ea-8938-f68e42db25b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/examination/model-question-and-answer-booklets')])[2]</value>
      <webElementGuid>edb1de54-b218-4fc7-8d6c-27ff7e149c79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[9]/a</value>
      <webElementGuid>ab325678-2d86-406c-a450-124c41c4780e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/examination/model-question-and-answer-booklets' and (text() = 'Specimen Question Cum Answer Booklet (QCAB)' or . = 'Specimen Question Cum Answer Booklet (QCAB)')]</value>
      <webElementGuid>8f05a7ee-71eb-4dd4-afec-1e0420a58cae</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
