<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_General Information</name>
   <tag></tag>
   <elementGuidId>cbaf8d19-365b-494a-975e-eded5e02c199</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.test.arrows > li > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-views-basic-page-block']/div/div/div/div/div/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;General Information&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>75f6c34f-6e55-499c-8705-d12416da6beb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/sites/default/files/Museum_Eng_20052022-F_1-1.pdf</value>
      <webElementGuid>060bb229-09fe-46ac-95c7-b0067f38fa1a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>b4864e3b-43d3-4fff-914f-b18a3b4e23be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>General Information </value>
      <webElementGuid>258dd505-2745-46e2-b144-3ef516b60db6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-views-basic-page-block&quot;)/div[@class=&quot;view view-basic-page view-id-basic_page view-display-id-block view-dom-id-2f158d84d2e29e8e196b858c190c0ec8&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;views-row views-row-1 views-row-odd views-row-first views-row-last&quot;]/div[@class=&quot;views-field views-field-body&quot;]/div[@class=&quot;field-content&quot;]/ul[@class=&quot;test arrows&quot;]/li[1]/a[1]</value>
      <webElementGuid>da160f08-eb77-4d03-bd19-83e59cceeb08</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-views-basic-page-block']/div/div/div/div/div/ul/li/a</value>
      <webElementGuid>a12e2557-e44a-4c4e-86b2-88d6b2dd6d4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'General Information')]</value>
      <webElementGuid>b63f44b8-638e-40e3-96c8-1dc488abf320</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UPSC Museum'])[2]/following::a[1]</value>
      <webElementGuid>49f5a2bb-97ae-4ef8-93fb-79213ae7dcea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Virtual Tour of Museum'])[2]/following::a[2]</value>
      <webElementGuid>f022c96b-ce44-4bfb-b9d2-d2c5ca76af59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(15.89 MB)'])[1]/preceding::a[1]</value>
      <webElementGuid>7ebff961-8559-4f33-86f9-6a9e86462947</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='General Information']/parent::*</value>
      <webElementGuid>c6e88f21-cb12-41dd-9c96-971657bb036d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/sites/default/files/Museum_Eng_20052022-F_1-1.pdf')]</value>
      <webElementGuid>737b6c21-98bf-415a-8eba-9226b2604d4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/section/div/div/div/div/div/ul/li/a</value>
      <webElementGuid>95e31a2a-d8b1-47c2-98d1-e167055305ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/sites/default/files/Museum_Eng_20052022-F_1-1.pdf' and (text() = 'General Information ' or . = 'General Information ')]</value>
      <webElementGuid>c503c5df-306d-4f2a-99ce-36347dd53680</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
