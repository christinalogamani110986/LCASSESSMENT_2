<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Public Disclosure of marks  other details_105b79</name>
   <tag></tag>
   <elementGuidId>dcd67ccb-a7d0-472b-8bc1-ea845a02754f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-2723 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[8]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Public Disclosure of marks &amp; other details of non-recommended willing candidates&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>8efe4fdd-e9ba-41bb-8fa7-75ae60a0d271</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/examination/public-disclosure-of-scores-through-portal</value>
      <webElementGuid>d7e22978-33de-48c6-9ecd-7bba20945840</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Public Disclosure of marks &amp; other details of non-recommended willing candidates</value>
      <webElementGuid>c6a6723a-6fa2-41b2-be4b-5de965ab14d0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-2723&quot;]/a[1]</value>
      <webElementGuid>1ddf65b3-925b-457f-915c-52395d9900a4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[8]/a</value>
      <webElementGuid>acf98555-445e-46b0-8c1b-29560175203a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Public Disclosure of marks &amp; other details of non-recommended willing candidates')])[2]</value>
      <webElementGuid>fe0e3a8f-b8bb-4806-9c34-d64e096b6abd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Marks Information'])[2]/following::a[1]</value>
      <webElementGuid>c7d4c775-9b1f-48d2-aad8-c20c8e193361</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Answer Keys'])[3]/following::a[2]</value>
      <webElementGuid>ffa7545f-d736-4608-859a-8569b94e83b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Specimen Question Cum Answer Booklet (QCAB)'])[2]/preceding::a[1]</value>
      <webElementGuid>54f25a96-2d06-4847-ba37-ee10be8034db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Common mistakes committed by the candidates in Conventional Papers'])[2]/preceding::a[2]</value>
      <webElementGuid>f3ad76f5-0b48-4985-b085-6df9084c7fe2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/examination/public-disclosure-of-scores-through-portal')])[2]</value>
      <webElementGuid>de0ef627-2ed1-4b6c-ad22-ecd785b45ac8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[8]/a</value>
      <webElementGuid>cfb506e6-3f89-4d9c-a6e5-ffa83ed464af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/examination/public-disclosure-of-scores-through-portal' and (text() = 'Public Disclosure of marks &amp; other details of non-recommended willing candidates' or . = 'Public Disclosure of marks &amp; other details of non-recommended willing candidates')]</value>
      <webElementGuid>786ce017-63c0-423e-af36-0dc7bbe8680b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
