<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Representation on Question Papers</name>
   <tag></tag>
   <elementGuidId>71abd625-c785-4c80-9795-b1cfaa1a5d49</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.last.leaf.menu-mlid-2755 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[9]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Representation on Question Papers&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>03458af5-35c3-4235-b3e9-6be816fcd980</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/recruitment/time-frame-representation</value>
      <webElementGuid>45e32985-4656-4aad-a37e-3557a2dcc389</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Representation on Question Papers</value>
      <webElementGuid>0b9e8d13-8a98-4b9c-a0a5-dbc3151d645b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;last leaf menu-mlid-2755&quot;]/a[1]</value>
      <webElementGuid>4ec242ad-6dd6-47d4-99f5-fbf24e550554</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[9]/a</value>
      <webElementGuid>cdac6caa-8681-4bcb-a6f7-560e1341339d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Representation on Question Papers')])[3]</value>
      <webElementGuid>48c0da15-a6ac-4684-a4e1-e712dabc41cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment cases kept on hold on account of Pending Litigations'])[3]/following::a[1]</value>
      <webElementGuid>3d2662e4-d08c-45bd-bd69-baa5026f36e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recruitment Requisition'])[2]/following::a[2]</value>
      <webElementGuid>6294a0f2-84f1-4b02-a4c6-39d03ff6d302</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(62.49 KB)'])[1]/preceding::a[2]</value>
      <webElementGuid>0dc087bf-f9ab-4831-ba1e-715c801dda11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/recruitment/time-frame-representation')])[2]</value>
      <webElementGuid>4b447625-a0a8-41cf-b6ec-c4be036cc440</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[9]/a</value>
      <webElementGuid>bf4bc9d2-4ba5-4575-95f4-8fd4205f4839</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/recruitment/time-frame-representation' and (text() = 'Representation on Question Papers' or . = 'Representation on Question Papers')]</value>
      <webElementGuid>7d4b1fa2-d9de-4532-9f43-53f2505f0e0e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
