<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Annual Calendar 2025</name>
   <tag></tag>
   <elementGuidId>5bf32d52-c560-4b9d-a367-c03c6710f46a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[type=&quot;application/pdf; length=53085&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@type='application/pdf; length=53085']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Annual Calendar 2025&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>1dd834d7-bf0c-4d5f-a6ff-54a9e6395f11</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://upsc.gov.in/sites/default/files/Calendar-Year-2025-engl-250424.pdf</value>
      <webElementGuid>e2737a27-6d77-4a16-b50d-248ca3498208</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_BLANK</value>
      <webElementGuid>54e4aa0e-9b6d-45d0-be1f-720d277bb230</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>PDF file that opens in a new window.</value>
      <webElementGuid>f63bd337-6eb1-4a08-8cca-6f943b918431</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>application/pdf; length=53085</value>
      <webElementGuid>83d56cb0-84f4-4aa5-8083-5fb6b34d4c10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Annual Calendar 2025</value>
      <webElementGuid>63f6afad-5a72-4de8-adf8-84e07e1d4555</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html not-front not-logged-in no-sidebars page-examinations page-examinations-exam-calendar i18n-en&quot;]/section[@class=&quot;wrapper body-wrapper&quot;]/div[@class=&quot;container body-container inner-body fontSize&quot;]/div[@class=&quot;col-xs-12 col-sm-9 col-md-9 content-container fontSize&quot;]/div[@class=&quot;inner-right&quot;]/div[@class=&quot;view view-exam-calendar view-id-exam_calendar view-display-id-page view-dom-id-89eb31fab17fc82f725ab89d7b26bfa0&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;scroll-table1&quot;]/table[@class=&quot;views-table cols-2 table table-0 table-0 table-0 table-0&quot;]/tbody[1]/tr[@class=&quot;odd views-row-first&quot;]/td[@class=&quot;views-field views-field-field-upload&quot;]/span[@class=&quot;file&quot;]/a[1]</value>
      <webElementGuid>ae23a16d-0c04-48e3-8797-9d7adc2f92db</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@type='application/pdf; length=53085']</value>
      <webElementGuid>1ef00887-bacc-4683-8f2e-98bffb9bac10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Annual Calendar 2025')]</value>
      <webElementGuid>7a88a765-2a73-452b-b8eb-a94176a7ec51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Date of Upload'])[1]/following::a[1]</value>
      <webElementGuid>fc0cdeb9-33e0-4acc-9e31-b2db2ea4fbab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Document'])[1]/following::a[1]</value>
      <webElementGuid>bfb05301-263d-4d0c-b42b-ad1e50cbafc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Revised Annual Calendar 2024'])[1]/preceding::a[1]</value>
      <webElementGuid>4acb707e-f063-497a-862c-9a85c9235bc6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Calendar 2024'])[1]/preceding::a[2]</value>
      <webElementGuid>3d5c9e78-8feb-4ac9-ade8-365400a4ff0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Annual Calendar 2025']/parent::*</value>
      <webElementGuid>03457fca-c7aa-4967-b0f2-a7612ba77170</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://upsc.gov.in/sites/default/files/Calendar-Year-2025-engl-250424.pdf')]</value>
      <webElementGuid>ef9ae8ec-8528-41da-a81f-e63cf15dbfa9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/a</value>
      <webElementGuid>0d9781ff-04be-4b3a-8350-c186d6f5947c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://upsc.gov.in/sites/default/files/Calendar-Year-2025-engl-250424.pdf' and @title = 'PDF file that opens in a new window.' and @type = 'application/pdf; length=53085' and (text() = 'Annual Calendar 2025' or . = 'Annual Calendar 2025')]</value>
      <webElementGuid>dfd52bb6-b2c3-4702-8771-ec6f18b617a1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
