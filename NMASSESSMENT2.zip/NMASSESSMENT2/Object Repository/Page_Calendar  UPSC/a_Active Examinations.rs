<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Active Examinations</name>
   <tag></tag>
   <elementGuidId>ed6bd29c-fa63-4892-8d83-7919ad64e78e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='main-menu']/ul/li[3]/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#main-menu >> internal:role=link[name=&quot;Active Examinations&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>1b85e430-b676-4af5-a5dc-748d69aab3cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/examinations/active-exams</value>
      <webElementGuid>12e7b8c3-fd0d-44b2-87a8-655268883e0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Active Examinations</value>
      <webElementGuid>98d7f415-e5e5-4ef4-b79a-db6d209a276b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main-menu&quot;)/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;expanded active-trail dropdown&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[@class=&quot;leaf fontSize&quot;]/a[1]</value>
      <webElementGuid>e7371d94-a287-444a-be45-34f512ce7134</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main-menu']/ul/li[3]/ul/li[2]/a</value>
      <webElementGuid>c8d87def-0202-46f3-8c55-4de8bd0f10da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Active Examinations')]</value>
      <webElementGuid>9cfe5e1b-6112-4d1f-ab2b-b87f082a72b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Calendar'])[1]/following::a[1]</value>
      <webElementGuid>82299b59-a1b1-4597-ac35-7354735070f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examination'])[1]/following::a[2]</value>
      <webElementGuid>6842a6e9-e5ad-4f7b-8d95-d545be9d127c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forthcoming Examinations'])[1]/preceding::a[1]</value>
      <webElementGuid>ac4e62b6-4fb5-4fd3-8be8-dee1a456b180</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous Question Papers'])[1]/preceding::a[2]</value>
      <webElementGuid>b4910c5a-587a-4c85-8d2c-56803eb69041</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Active Examinations']/parent::*</value>
      <webElementGuid>02d7df99-628d-406f-a712-5b351f358f7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/examinations/active-exams')]</value>
      <webElementGuid>04d94da5-7d48-486b-841d-59a9644e665b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/ul/li[2]/a</value>
      <webElementGuid>c3d85032-3280-409e-8cb1-59e917267dc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/examinations/active-exams' and (text() = 'Active Examinations' or . = 'Active Examinations')]</value>
      <webElementGuid>8ccd88d8-b89f-4e85-b20d-151274b7db0a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
