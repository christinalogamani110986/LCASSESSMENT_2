<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_72nd Annual Report</name>
   <tag></tag>
   <elementGuidId>6f468c2d-5040-444b-9c9b-1ac605f31a27</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Year'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;72nd Annual Report&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>d4d154b0-a511-4541-bc5f-411b02b9c499</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>72nd Annual Report</value>
      <webElementGuid>7da31b6b-d19b-48c7-8e05-e80a7f600071</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js bootstrap-anchors-processed&quot;]/body[@class=&quot;html not-front not-logged-in no-sidebars page-annual-reports i18n-en&quot;]/section[@class=&quot;wrapper body-wrapper&quot;]/div[@class=&quot;container body-container inner-body fontSize&quot;]/div[@class=&quot;col-xs-12 col-sm-9 col-md-9 content-container fontSize&quot;]/div[@class=&quot;inner-right&quot;]/div[@class=&quot;view view-annual-reports view-id-annual_reports view-display-id-page view-dom-id-304a21f250ce58b5089f4473bf813e41&quot;]/div[@class=&quot;view-content&quot;]/div[@class=&quot;scroll-table1&quot;]/table[@class=&quot;views-table cols-2 table&quot;]/tbody[1]/tr[@class=&quot;odd views-row-first&quot;]/td[@class=&quot;views-field views-field-title&quot;]/a[1]/p[1]</value>
      <webElementGuid>0a4d15cf-262c-45ac-8973-d41d06b31da3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Year'])[1]/following::p[1]</value>
      <webElementGuid>480125ac-b3b9-4530-8c43-b3ce1a2cee1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reports'])[1]/following::p[1]</value>
      <webElementGuid>2277114a-3a22-4a56-83d7-863e77fecdb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Other Statistical Information'])[1]/preceding::p[1]</value>
      <webElementGuid>3fac06d4-ddb0-40e2-aed0-8296e80fa893</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Other Statistical Information'])[2]/preceding::p[3]</value>
      <webElementGuid>bc678baa-3017-49f3-95a4-8fd350a06acc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='72nd Annual Report']/parent::*</value>
      <webElementGuid>b5fc295d-f0f6-4d0b-90c4-2b037f133ebc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>82dc0dc1-e83a-43e2-b2f5-7a7433910a84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '72nd Annual Report' or . = '72nd Annual Report')]</value>
      <webElementGuid>0d2aa4d1-a30a-4028-aad6-a32ce0ef147d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
