<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Article-322. Expenses of Public Service C_bd48e0</name>
   <tag></tag>
   <elementGuidId>37e03601-fbf4-4457-8b06-d8641cbe0e4c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.leaf.menu-mlid-1473 > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='block-menu-block-2']/div/ul/li[8]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Article-322. Expenses of Public Service Commissions.&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>edd58505-eb57-4df0-8a8e-501051b8cd69</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/about-us/constitutional-provisions/article-322-expenses-public-service-commissions</value>
      <webElementGuid>4e975f69-1e58-43c1-acfb-80def2139b78</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Article-322. Expenses of Public Service Commissions.</value>
      <webElementGuid>dfc325b8-bf16-498d-8eda-f138a38f3bdd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-menu-block-2&quot;)/div[@class=&quot;menu-block-wrapper menu-block-2 menu-name-main-menu parent-mlid-0 menu-level-2&quot;]/ul[@class=&quot;menu nav&quot;]/li[@class=&quot;leaf menu-mlid-1473&quot;]/a[1]</value>
      <webElementGuid>6f1fb4ec-c191-486d-9e9d-801c6ee5aa23</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='block-menu-block-2']/div/ul/li[8]/a</value>
      <webElementGuid>5b084b79-5b1d-46ff-b60b-695ed95912ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Article-322. Expenses of Public Service Commissions.')]</value>
      <webElementGuid>a805ea02-099c-43b2-b2c7-d67c32c3370c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.'])[2]/following::a[1]</value>
      <webElementGuid>164d0755-75d8-4d1d-8bbe-1852f7fce8c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-320. Functions of Public Service Commissions.'])[1]/following::a[2]</value>
      <webElementGuid>cad8dd63-2abd-4b2f-96e4-32bb09a2472a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-323. Reports of Public Service Commissions.'])[1]/preceding::a[1]</value>
      <webElementGuid>ceaa0327-495c-4528-a09f-3818295c4d7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Article-321. Power to extend functions of Public Service Commissions.'])[3]/preceding::a[3]</value>
      <webElementGuid>89e5e5c3-d870-4c1f-bf30-9ff49f170e63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Article-322. Expenses of Public Service Commissions.']/parent::*</value>
      <webElementGuid>9df7780e-582c-42f2-b3c9-d72a0a261287</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/about-us/constitutional-provisions/article-322-expenses-public-service-commissions')]</value>
      <webElementGuid>27f799e2-756d-4278-82ec-20383b42d4b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/ul/li[8]/a</value>
      <webElementGuid>9bb8b6cd-9ca8-4b0a-be0d-98cabbe9e993</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/about-us/constitutional-provisions/article-322-expenses-public-service-commissions' and (text() = 'Article-322. Expenses of Public Service Commissions.' or . = 'Article-322. Expenses of Public Service Commissions.')]</value>
      <webElementGuid>c83ea289-30ab-411f-9bee-64bc6be1e28e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
