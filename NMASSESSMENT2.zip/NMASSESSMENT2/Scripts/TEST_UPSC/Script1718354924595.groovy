import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://upsc.gov.in/')

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/a_SiteMap'))

WebUI.switchToWindowTitle('Sitemap | UPSC')

WebUI.setText(findTestObject('Object Repository/Page_Sitemap  UPSC/input_Search form_search_block_form'), 'RECRUITMENT')

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/a_A'))

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/a_A_1'))

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/sup_-'))

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/sup_-'))

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/a_A_1_2'))

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/a_A_1_2_3'))

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/sup_'))

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/sup_'))

WebUI.click(findTestObject('Object Repository/Page_Search  UPSC/i_Toggle navigation_fa fa-home'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/a_Historical Perspective'))

WebUI.click(findTestObject('Object Repository/Page_Historical Perspective  UPSC/a_(18.08 KB)'))

WebUI.switchToWindowTitle('Historical Perspective | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Historical Perspective  UPSC/span_About Us'))

WebUI.click(findTestObject('Object Repository/Page_Historical Perspective  UPSC/span_About Us'))

WebUI.click(findTestObject('Object Repository/Page_Historical Perspective  UPSC/a_Home'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/a_Constitutional Provisions'))

WebUI.click(findTestObject('Object Repository/Page_Constitutional Provisions  UPSC/a_Article-315. Public Service Commissions f_9342bd'))

WebUI.click(findTestObject('Object Repository/Page_Article-315. Public Service Commission_8625e2/a_Article-316. Appointment and term of offi_2c16a6'))

WebUI.click(findTestObject('Object Repository/Page_Article-316. Appointment and term of o_ac782f/a_Article-317. Removal and suspension of a _1a82c7'))

WebUI.click(findTestObject('Object Repository/Page_Article-317. Removal and suspension of_d8ed27/a_Article-318. Power to make regulations as_026201'))

WebUI.click(findTestObject('Object Repository/Page_Article-318. Power to make regulations_f9dfee/a_Article-319. Prohibition as to the holdin_93b2a0'))

WebUI.click(findTestObject('Object Repository/Page_Article-319. Prohibition as to the hol_98dc15/a_Article-317. Removal and suspension of a _1a82c7'))

WebUI.click(findTestObject('Object Repository/Page_Article-317. Removal and suspension of_d8ed27/a_Article-318. Power to make regulations as_026201'))

WebUI.click(findTestObject('Object Repository/Page_Article-318. Power to make regulations_f9dfee/a_Article-319. Prohibition as to the holdin_93b2a0'))

WebUI.click(findTestObject('Object Repository/Page_Article-319. Prohibition as to the hol_98dc15/a_Article-320. Functions of Public Service _b14684'))

WebUI.click(findTestObject('Object Repository/Page_Article-320. Functions of Public Servi_8bc159/a_Article-321. Power to extend functions of_16a5e6'))

WebUI.click(findTestObject('Object Repository/Page_Article-321. Power to extend functions_f88927/a_Article-322. Expenses of Public Service C_bd48e0'))

WebUI.click(findTestObject('Object Repository/Page_Article-322. Expenses of Public Servic_b59da0/a_Article-323. Reports of Public Service Co_b2187b'))

WebUI.click(findTestObject('Object Repository/Page_Article-323. Reports of Public Service_741bd8/a_The Commission'))

WebUI.click(findTestObject('Object Repository/Page_The Commission  UPSC/strong_Dr. Manoj Soni'))

WebUI.click(findTestObject('Object Repository/Page_Dr. Manoj Soni  UPSC/a_(71.82 KB)'))

WebUI.switchToWindowTitle('The Commission | UPSC')

WebUI.click(findTestObject('Object Repository/Page_The Commission  UPSC/a_Functions'))

WebUI.click(findTestObject('Object Repository/Page_Functions  UPSC/a_Secretariat'))

WebUI.click(findTestObject('Object Repository/Page_Secretariat  UPSC/a_Divisions'))

WebUI.click(findTestObject('Object Repository/Page_Divisions  UPSC/a_Administration'))

WebUI.click(findTestObject('Object Repository/Page_Administration  UPSC/a_Introduction'))

WebUI.click(findTestObject('Object Repository/Page_Introduction  UPSC/a_Administration'))

WebUI.click(findTestObject('Object Repository/Page_Administration  UPSC/a_Personnel'))

WebUI.click(findTestObject('Object Repository/Page_Personnel  UPSC/a_Functions'))

WebUI.click(findTestObject('Object Repository/Page_Functions  UPSC/a_Recruitment Rules'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment Rules  UPSC/a_Draft Recruitment Rules of UPSC'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment Rules  UPSC/a_Notified Recruitment Rules related to UPSC Posts'))

WebUI.click(findTestObject('Object Repository/Page_Notified Recruitment Rules related to _f5f2c2/a_(518.87 KB)'))

WebUI.click(findTestObject('Object Repository/Page_Notified Recruitment Rules related to _f5f2c2/a_Divisions'))

WebUI.click(findTestObject('Object Repository/Page_Divisions  UPSC/a_Citizens Charter'))

WebUI.click(findTestObject('Object Repository/Page_Citizens Charter  UPSC/a_Directory'))

WebUI.click(findTestObject('Object Repository/Page_Directory  UPSC/a_Museum'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum  UPSC/a_General Information'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum  UPSC/a_Virtual Tour of Museum'))

WebUI.switchToWindowTitle('UPSC Museum VR Developed By Vibgyor Studios Delhi | Virtual tour generated by Vibgyor Studios')

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/div'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/div'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/div'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/div'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/div'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/div_Next Spot'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/a_CLOSE_closeBtn'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/a_CLOSE_closeBtn'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/p_CLOSE_kolorBoxBodyCenterRightArrow'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/div_CLOSE_kolorBoxTopUIBar'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/a_CLOSE_closeBtn'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/p_CLOSE_kolorBoxBodyCenterRightArrow'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/p_CLOSE_kolorBoxBodyCenterRightArrow'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/p_CLOSE_kolorBoxBodyCenterRightArrow'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/p_CLOSE_kolorBoxBodyCenterRightArrow'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/a_CLOSE_closeBtn'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3_4'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3_4_5'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/a_CLOSE_closeBtn'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3_4_5_6'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3_4_5_6_7'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3_4_5_6_7_8'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3_4_5_6_7_8_9'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon_1_2_3_4_5_6_7_8_9_10'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/polygon'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/svg'))

WebUI.switchToWindowTitle('UPSC Museum | UPSC')

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum  UPSC/a_Archived Documents in Museum'))

WebUI.switchToWindowTitle('Archived Documents in Museum | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Archived Documents in Museum  UPSC/a_Calendar'))

WebUI.click(findTestObject('Object Repository/Page_Calendar  UPSC/a_Annual Calendar 2025'))

WebUI.click(findTestObject('Object Repository/Page_Calendar  UPSC/a_Active Examinations'))

WebUI.click(findTestObject('Object Repository/Page_Active Examinations  UPSC/a_Forthcoming Examinations'))

WebUI.click(findTestObject('Object Repository/Page_Forthcoming Examinations  UPSC/a_Previous Question Papers'))

WebUI.click(findTestObject('Object Repository/Page_Previous Year Question Papers  UPSC/a_Cut-off Marks'))

WebUI.click(findTestObject('Object Repository/Page_Cut-off Marks  UPSC/a_Marks Information'))

WebUI.switchToWindowTitle('UPSC -MARKSHEET')

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/font_Click Here'))

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/input_Select any of the given option_admit'))

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/input_By Registration Id_admit'))

WebUI.switchToWindowTitle('Cut-off Marks | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Cut-off Marks  UPSC/a_Answer Keys'))

WebUI.click(findTestObject('Object Repository/Page_Answer Keys  UPSC/a_Marks Information'))

WebUI.switchToWindowTitle('UPSC -MARKSHEET')

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/font_Click Here'))

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/td_By Roll Number'))

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/input_By Registration Id_admit'))

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/span_Note No Alphabet , No Special Characte_3e69d5'))

WebUI.setText(findTestObject('Object Repository/Page_UPSC -MARKSHEET/input_Enter Your Roll Number_candidate_rollno'), '4534545')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_UPSC -MARKSHEET/select_DD                                  _172988'), 
    '04', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_UPSC -MARKSHEET/select_MM                    Jan           _e9bba0'), 
    '07', true)

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/td_DD                                  01  _f1cd7d'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_UPSC -MARKSHEET/select_YYYY                    197019711972_3846e0'), 
    '1977', true)

WebUI.setText(findTestObject('Object Repository/Page_UPSC -MARKSHEET/input_Enter the code above here_letters_code'), '245R3D')

WebUI.click(findTestObject('Object Repository/Page_UPSC -MARKSHEET/input_NoteCaptcha Code is Case Sensitive_su_67747b'))

WebUI.click(findTestObject('Object Repository/Page_Answer Keys  UPSC/a_Marks Information'))

WebUI.switchToWindowTitle('Answer Keys | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Answer Keys  UPSC/a_Public Disclosure of marks  other details_105b79'))

WebUI.click(findTestObject('Object Repository/Page_Public Disclosure of marks  other deta_ee636f/a_Specimen Question Cum Answer Booklet (QCAB)'))

WebUI.click(findTestObject('Object Repository/Page_Specimen Question Cum Answer Booklets  UPSC/a_Common mistakes committed by the candidat_eb77f1'))

WebUI.click(findTestObject('Object Repository/Page_Common mistakes committed by the candi_025a02/a_Revised Syllabus and Scheme'))

WebUI.click(findTestObject('Object Repository/Page_Revised Syllabus and Scheme  UPSC/a_Representation on Question Papers'))

WebUI.click(findTestObject('Object Repository/Page_Representation on Question Papers  UPSC/a_Demo Files'))

WebUI.click(findTestObject('Object Repository/Page_Demo Files for Computer Based Combined_4aa543/a_Advertisements'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment Advertisements  UPSC/a_Status of Lateral Recruitment Cases (Adve_05e45d'))

WebUI.click(findTestObject('Object Repository/Page_Status of Lateral Recruitment Cases (A_5cd0ae/a_Applicants List'))

WebUI.setText(findTestObject('Object Repository/Page_Applicants List  UPSC/input_Advertisement Number_field_advertisem_c44aa8'), 
    '1')

WebUI.setText(findTestObject('Object Repository/Page_Applicants List  UPSC/input_Name of Post_field_name_of_post_vacca_e8a1fa'), 
    'FRGFDG')

WebUI.click(findTestObject('Object Repository/Page_Applicants List  UPSC/input_Name of Post_field_name_of_post_vacca_e8a1fa'))

WebUI.setText(findTestObject('Object Repository/Page_Applicants List  UPSC/input_Vacancy Number_field_vacancy_number_value'), 
    'FGRFTERT')

WebUI.click(findTestObject('Object Repository/Page_Applicants List  UPSC/button_Apply'))

WebUI.click(findTestObject('Object Repository/Page_Applicants List  UPSC/a_Notices'))

WebUI.click(findTestObject('Object Repository/Page_Notices  UPSC/a_Corrigendum'))

WebUI.click(findTestObject('Object Repository/Page_Corrigendum  UPSC/a_Scrutiny'))

WebUI.click(findTestObject('Object Repository/Page_Scrutiny  UPSC/a_Interview Schedules'))

WebUI.click(findTestObject('Object Repository/Page_Interview Schedules  UPSC/a_Results'))

WebUI.setText(findTestObject('Object Repository/Page_Results  UPSC/input_Advertisement Number_field_advertisem_c44aa8'), 
    '10')

WebUI.click(findTestObject('Object Repository/Page_Results  UPSC/button_Apply'))

WebUI.click(findTestObject('Object Repository/Page_Results  UPSC/a_Marks Information'))

WebUI.switchToWindowTitle('Results | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Results  UPSC/a_Status of Lateral Recruitment Cases (Adve_05e45d'))

WebUI.click(findTestObject('Object Repository/Page_Status of Lateral Recruitment Cases (A_5cd0ae/a_Online Recruitment Application (ORA)'))

WebUI.click(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) V_5b8570/a_Instructions for filling Application'))

WebUI.click(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) V_5b8570/a_General Technical Issues'))

WebUI.click(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) V_5b8570/a_Frequently Asked Questions(FAQ)'))

WebUI.switchToWindowTitle('ONLINE RECRUITMENT APPLICATION (ORA) Vacancy Notice')

WebUI.click(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) V_5b8570/a_New Registration'))

WebUI.setText(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_Name_fstname'), 
    'RTRETRTERT')

WebUI.setText(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_Name_middlename'), 
    'RTRETTRYTY')

WebUI.setText(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_Name_lastname'), 
    'TYTY')

WebUI.click(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_Name_lastname'))

WebUI.setText(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_concat(    Father, , s Name)_fatherfstname'), 
    'TYTY')

WebUI.click(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_concat(    Father, , s Name)_fatherfstname'))

WebUI.setText(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_concat(    Father, , s Name)_fathermi_a36c18'), 
    'TY45')

WebUI.setText(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_concat(    Father, , s Name)_fatherlastname'), 
    '')

WebUI.click(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_concat(    Mother, , s Name)_motherfstname'))

WebUI.click(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/input_Confirm Random Image_submit'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/select_--Select Gender--                   _8fdd8d'), 
    'Male', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_ONLINE RECRUITMENT APPLICATION (ORA) P_22423a/select_--Select--GENOBCSCSTEWS'), 
    'GEN', true)

WebUI.switchToWindowTitle('Status of Lateral Recruitment Cases (Advertisement-wise) | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Status of Lateral Recruitment Cases (A_5cd0ae/a_Status of Recruitment Cases (Advertisement-wise)'))

WebUI.click(findTestObject('Object Repository/Page_Status of Recruitment Cases (Advertise_f1eb27/a_Forms for Certificates'))

WebUI.click(findTestObject('Object Repository/Page_Forms for Certificates  UPSC/a_Recruitment Tests'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment Tests  UPSC/li_Schedule for Recruitment Tests  Interviews'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment Tests  UPSC/a_Schedule for Recruitment Tests  Interviews'))

WebUI.switchToWindowTitle('Interview Details | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Interview Details  UPSC/a_(315.93 KB)'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment Tests  UPSC/a_e-admit Card'))

WebUI.switchToWindowTitle('Recruitment Tests | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Recruitment Tests  UPSC/a_Recruitment Requisition'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment Requisition  UPSC/a_Recruitment cases kept on hold on account_51ce53'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment cases kept on hold on acco_c3568e/a_Representation on Question Papers'))

WebUI.click(findTestObject('Object Repository/Page_Representation on Question Papers  UPSC/a_One Time Registration (OTR) for Examinations'))

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input_(as per Class X)_name'), 'R4545')

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input__name_ver'), '4545')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_UPSC/select_Select Changed Name OptionYesNo'), '1', true)

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input_Changed Name_full_name'), 'RTE')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_UPSC/select_GenderMaleFemaleTransgender'), '2', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_UPSC/select_Verify Gender MaleFemaleTransgender'), '2', 
    true)

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input__dob'), '324234')

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input__dob_ver'), '4545')

WebUI.click(findTestObject('Object Repository/Page_UPSC/input__dob_ver'))

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input__father_name'), '5656656RT')

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input__father_name_ver'), 'GYETEW')

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input__mother_name'), 'UYTTRYE')

WebUI.setText(findTestObject('Object Repository/Page_UPSC/input__mother_name_ver'), 'TY56RT')

WebUI.click(findTestObject('Object Repository/Page_UPSC/input__register_here'))

WebUI.click(findTestObject('Object Repository/Page_UPSC/b_Home'))

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum  UPSC/a_Virtual Tour of Museum_1'))

WebUI.switchToWindowTitle('UPSC Museum VR Developed By Vibgyor Studios Delhi | Virtual tour generated by Vibgyor Studios')

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum VR Developed By Vibgyor St_6587ea/div_1'))

WebUI.switchToWindowTitle('UPSC Museum | UPSC')

WebUI.click(findTestObject('Object Repository/Page_UPSC Museum  UPSC/a_Advertisements'))

WebUI.click(findTestObject('Object Repository/Page_Recruitment Advertisements  UPSC/a_Central Government'))

WebUI.click(findTestObject('Object Repository/Page_Central Government  UPSC/a_Union Territories Government'))

WebUI.click(findTestObject('Object Repository/Page_Union Territories Government  UPSC/a_State Government'))

WebUI.click(findTestObject('Object Repository/Page_State Government  UPSC/a_Others'))

WebUI.click(findTestObject('Object Repository/Page_Others  UPSC/a_Forms  Downloads'))

WebUI.click(findTestObject('Object Repository/Page_Forms and Downloads  UPSC/a_(620.22 KB)'))

WebUI.switchToWindowTitle('Forms and Downloads | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Forms and Downloads  UPSC/a_FAQs'))

WebUI.click(findTestObject('Object Repository/Page_FAQs  UPSC/a_Policy and Coordination Branch'))

WebUI.click(findTestObject('Object Repository/Page_FAQs  UPSC/a_(302.2 KB)'))

WebUI.switchToWindowTitle('FAQs | UPSC')

WebUI.click(findTestObject('Object Repository/Page_FAQs  UPSC/a_RTI'))

WebUI.click(findTestObject('Object Repository/Page_Right to Information  UPSC/a_Website Policies'))

WebUI.click(findTestObject('Object Repository/Page_Website Policies  UPSC/a_Help'))

WebUI.click(findTestObject('Object Repository/Page_Help  UPSC/a_PowerPoint Viewer 2003 (in any version ti_3eea61'))

WebUI.click(findTestObject('Object Repository/Page_Help  UPSC/a_Adobe Flash Player'))

WebUI.switchToWindowTitle('Help | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Help  UPSC/a_Web Information Manager'))

WebUI.click(findTestObject('Object Repository/Page_Web Information Manager  UPSC/a_Feedback'))

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/input__submittedname'), 'T4W6')

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/input__submittedemail_address'), 'RTRTRT')

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/textarea__submittedfeedback'), '454GRTRT')

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/input__captcha_response'), 'M5ssmqw')

WebUI.click(findTestObject('Object Repository/Page_Feedback  UPSC/button_Submit'))

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/input__submittedemail_address'), 'RTRTRT@')

WebUI.click(findTestObject('Object Repository/Page_Feedback  UPSC/button_Submit'))

WebUI.click(findTestObject('Object Repository/Page_Feedback  UPSC/a_Web Information Manager'))

WebUI.click(findTestObject('Object Repository/Page_Web Information Manager  UPSC/a_Feedback'))

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/input__submittedname'), 'test')

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/input__submittedemail_address'), 'test@gmail.com')

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/textarea__submittedfeedback'), 'good')

WebUI.setText(findTestObject('Object Repository/Page_Feedback  UPSC/input__captcha_response'), 'm5SSMQW')

WebUI.click(findTestObject('Object Repository/Page_Feedback  UPSC/button_Submit'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Feedback  UPSC/select_Examination Recruitment Technical  Others'), 
    'web-upsc@nic.in ', true)

WebUI.click(findTestObject('Object Repository/Page_Feedback  UPSC/button_Submit'))

WebUI.click(findTestObject('Object Repository/Page_Feedback submitted successfully  UPSC/a_Disclaimer'))

WebUI.click(findTestObject('Object Repository/Page_Disclaimer  UPSC/a_Home'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Examination Notifications'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Recruitment Advertisements'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Apply Online'))

WebUI.click(findTestObject('Object Repository/Page_Apply Online  UPSC/a_One Time Registration (OTR) for Examinati_4eea8d'))

WebUI.switchToWindowTitle('Welcome to UPSC | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Admit Cards'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Written Results'))

WebUI.click(findTestObject('Object Repository/Page_Written Results  UPSC/a_Disclaimer'))

WebUI.click(findTestObject('Object Repository/Page_Disclaimer  UPSC/a_Home'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/li_e - Admit Card Engineering Services (Mai_e72e06'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/div_Press Note Indian Economic Service - In_d1170a'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/a_Rectt. Test 323 vacancies for the post of_4f209c'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/li_Interview Details 42 Posts of Labour Enf_03b159'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/a_Interview Details 42 Posts of Labour Enfo_2dc322'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/div_Press Note Indian Economic Service - In_d1170a'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/div_Press Note Indian Economic Service - In_d1170a'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Tenders'))

WebUI.click(findTestObject('Object Repository/Page_Tenders  UPSC/span_Annual Reports'))

WebUI.click(findTestObject('Object Repository/Page_Annual Reports  UPSC/p_72nd Annual Report'))

WebUI.click(findTestObject('Object Repository/Page_72nd Annual Report  UPSC/span_Content'))

WebUI.click(findTestObject('Object Repository/Page_72nd Annual Report  UPSC/a_Home'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/a_Representation on Question Papers'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Tenders'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Single Window System  e-Appointment'))

WebUI.click(findTestObject('Object Repository/Page_Single Window System  e-Appointment  UPSC/span_Court Judgments'))

WebUI.switchToWindowTitle('Single Window System | e-Appointment | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Single Window System  e-Appointment  UPSC/a_Green Initiatives'))

WebUI.closeBrowser()

WebUI.switchToWindowTitle('Welcome to UPSC | UPSC')

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/span_Green Initiatives'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UPSC  UPSC/a_View all'))

WebUI.click(findTestObject('Object Repository/Page_Forthcoming Examinations  UPSC/a_Demo Files'))

WebUI.click(findTestObject('Object Repository/Page_Demo Files for Computer Based Combined_4aa543/a_Click Here'))

WebUI.switchToWindowTitle('Login')

WebUI.click(findTestObject('Object Repository/Page_Login/span_Sign In'))

